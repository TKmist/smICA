'''
This file is part of the smICA repository that is distributed under the MIT license; see below.


############################################################################

MIT License

Copyright (c) 2026 Tomasz Kalwarczyk

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
'''

import dearpygui.dearpygui as dpg
import os
import json
import pandas as pd
import numpy as np
from numpy import log10, sqrt, exp, log, pi
import time
import pickle
import cv2
from Required.automated_roi import ImageROIProcessor
from Modes.Extract_from_PTU.include import resolve_integrated_frame_count
from scipy.stats import median_abs_deviation
from scipy.signal import fftconvolve
import pickle
from scipy import constants
import Required.INIT as inits

bf = inits._basicF()

lprint = bf.lnprint
globalITEMS = inits._common_VARIABLES()
###############################################################################
###############################################################################
''' Inits'''


###############################################################################
###############################################################################


class _Phot2conc_init:

    def __init__(self,
                 size_ratio,
                 left_indent,
                 internal_indent,
                 right_indent,
                 bottom_indent,
                 top_indent,
                 group_spacer,
                 font_size,
                 last_directory, GI):
        '''General variables'''
        self.last_directory = last_directory

        self.GI = GI

        '''Layout variables'''
        self.size_ratio = size_ratio
        self.left_indent = int(left_indent * self.size_ratio['width'])
        self.internal_indent = int(internal_indent * self.size_ratio['width'])
        self.right_indent = int(right_indent * self.size_ratio['width'])
        self.bottom_indent = int(bottom_indent * self.size_ratio['width'])
        self.top_indent = int(top_indent * self.size_ratio['width'])
        self.group_spacer = int(group_spacer * self.size_ratio['width'])
        self.fnt_ratio = (self.size_ratio['width'] + self.size_ratio['height']) / 2
        self.font_size = int(np.round(font_size * self.fnt_ratio, 0))
        self.im_scaller = int(32)  # 1.1
        self.files = []

        self.NO_IMAGE_INTENSITY = np.load(os.path.join('res', 'img', 'NO_image_INT.npy'))

        self.ROI_mode_items = ['',
                               'find dark',
                               'subtract dark',
                               'find bright',
                               'subtract bright',
                               'find many bright spots',
                               'subtract many bright spots'
                               ]
        dpg.set_global_font_scale(self.fnt_ratio)
        self.img_border = 60
        self.PTU_DATA_window = {'name': 'PTU_DATA_window',
                                'width': int(380 * self.size_ratio['width']),
                                'height': int(175 * self.size_ratio['height']),
                                # 'height':int(315*self.size_ratio['height']),
                                'pos': (self.left_indent, self.top_indent)
                                }

        self.file_window = {'name': 'file_window',
                            'width': int(380 * self.size_ratio['width']),
                            'height': dpg.get_viewport_height() - (self.top_indent + self.PTU_DATA_window[
                                'height'] + self.internal_indent + self.bottom_indent),
                            'pos': (
                                self.left_indent,
                                self.top_indent + self.PTU_DATA_window['height'] + self.internal_indent)
                            }
        self.image_window_ch1 = {'name': 'image_window_ch1',
                                 'width': int(386 * self.size_ratio['width']),
                                 'height': int((392 * self.size_ratio['width'] + (self.img_border))),
                                 'pos': (self.left_indent + self.PTU_DATA_window['width'] + self.internal_indent,
                                         self.top_indent)
                                 }
        self.image_window_ch2 = {'name': 'image_window_ch2',
                                 'width': int(386 * self.size_ratio['width']),
                                 'height': int(392 * self.size_ratio['width'] + self.img_border),
                                 'pos': (self.image_window_ch1['pos'][0] + self.image_window_ch1[
                                     'width'] + self.internal_indent,
                                         self.top_indent)
                                 }
        self.tex_1_name = 'texture_tag_chan_1'
        self.tex_2_name = 'texture_tag_chan_2'

        if 'texture_reg' in dpg.get_aliases():
            pass
        else:
            dpg.add_texture_registry(show=False, tag='texture_reg')
            self.GI.extend(['texture_reg'])
            self.processor_1 = ImageROIProcessor()
            self.processor_1.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
            self.processor_2 = ImageROIProcessor()
            self.processor_2.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
            self.rgba_image_1 = self.im_to_rgbim(self.processor_1.image)
            self.rgba_image_2 = self.im_to_rgbim(self.processor_2.image)
            self.rgba_image_1 = cv2.resize(self.rgba_image_1,
                                           (int(self.image_window_ch1['width'] - self.im_scaller),
                                            int(self.image_window_ch1['width'] - self.im_scaller)),
                                           interpolation=cv2.INTER_LINEAR)
            self.rgba_image_2 = cv2.resize(self.rgba_image_2,
                                           (int(self.image_window_ch2['width'] - self.im_scaller),
                                            int(self.image_window_ch2['width'] - self.im_scaller)),
                                           interpolation=cv2.INTER_LINEAR)
            dpg_image_1 = (self.rgba_image_1.astype(np.float64) / np.max(self.rgba_image_1)).flatten().tolist()
            dpg_image_2 = (self.rgba_image_2.astype(np.float64) / np.max(self.rgba_image_2)).flatten().tolist()
            dpg.add_dynamic_texture(width=int(self.image_window_ch1['width'] - self.im_scaller),
                                    height=int(self.image_window_ch1['width'] - self.im_scaller),
                                    default_value=dpg_image_1,
                                    tag=self.tex_1_name,
                                    parent='texture_reg')
            dpg.add_dynamic_texture(width=int(self.image_window_ch2['width'] - self.im_scaller),
                                    height=int(self.image_window_ch2['width'] - self.im_scaller),
                                    default_value=dpg_image_2,
                                    tag=self.tex_2_name,
                                    parent='texture_reg')

        self.shift = 8
        self.hist_window_ch1 = {'name': 'hist_window_ch1',
                                'width': self.image_window_ch1['width'],
                                'height': dpg.get_viewport_height() - (
                                        self.image_window_ch1['pos'][1] + self.image_window_ch1[
                                    'height'] + self.internal_indent + self.bottom_indent),
                                'pos': (self.image_window_ch1['pos'][0],
                                        self.image_window_ch1['pos'][1] + self.image_window_ch1[
                                            'height'] + self.internal_indent)
                                }

        self.hist_window_ch2 = {'name': 'hist_window_ch2',
                                'width': self.image_window_ch2['width'],
                                'height': dpg.get_viewport_height() - (
                                        self.image_window_ch2['pos'][1] + self.image_window_ch2[
                                    'height'] + self.internal_indent + self.bottom_indent),
                                'pos': (self.image_window_ch2['pos'][0],
                                        self.image_window_ch2['pos'][1] + self.image_window_ch2[
                                            'height'] + self.internal_indent)
                                }

        self.DISP_OPT_window = {'name': 'DISP_OPT_window',
                           'width': dpg.get_viewport_width() - (self.image_window_ch2['pos'][0] + self.image_window_ch2[
                               'width'] + self.internal_indent + self.right_indent),
                           'height': int(134 * self.size_ratio['height']),
                           'pos': (self.left_indent + self.PTU_DATA_window['width'] + self.internal_indent +
                                   self.image_window_ch1['width'] + int(self.internal_indent) + self.image_window_ch2[
                                       'width'] + int(self.internal_indent),
                                   self.top_indent)
                           }
        self.DISP_OPT_combo = {'name': 'DISP_OPT_combo',
                                    'width': -1,
                                    'items': ['Foreground intensity',
                                              'Background intensity',
                                              'Foreground decay times',
                                             ]
                                    }

        self.FCS_window = {'name': 'FCS_window',
                           'width': dpg.get_viewport_width() - (self.image_window_ch2['pos'][0] + self.image_window_ch2[
                               'width'] + self.internal_indent + self.right_indent),
                           'height': int(406 * self.size_ratio['height']),
                           'pos': (self.DISP_OPT_window['pos'][0],
                                   self.top_indent + self.DISP_OPT_window['height'] + self.internal_indent)
                           }

        self.results_window = {'name': 'results_window',
                               'width': self.FCS_window['width'],
                               'height': int(360 * self.size_ratio['height']),
                               'pos': (self.FCS_window['pos'][0],
                                       self.top_indent + self.DISP_OPT_window['height'] + self.internal_indent + self.FCS_window['height'] + self.internal_indent)
                               }

        self.Resolution_output = {'name': 'Resolution_output',
                                  'width': -1
                                  }
        self.Pixel_size_output = {'name': 'Pixel_size_output',
                                  'width': -1
                                  }
        self.Nframes_output = {'name': 'Nframes_output',
                               'width': -1
                               }
        self.Pixel_dwell_output = {'name': 'Pixel_dwell_output',
                                   'width': -1
                                   }
        self.Resol_Pix_size_table_col1 = {'name': 'Resol_Pix_size_table_col1',
                                          'width': int(self.PTU_DATA_window['width'] / 2)
                                          }
        self.Resol_Pix_size_table_col2 = {'name': 'Resol_Pix_size_table_col2',
                                          'width': int(self.PTU_DATA_window['width'] / 2)
                                          }
        self.ROI_table_col1 = {'name': 'ROI_table_col1',
                               'width': int(self.PTU_DATA_window['width'] / 3)
                               }
        self.ROI_table_col2 = {'name': 'ROI_table_col2',
                               'width': int(self.PTU_DATA_window['width'] / 3)
                               }
        self.ROI_table_col3 = {'name': 'ROI_table_col3',
                               'width': int(self.PTU_DATA_window['width'] / 3)
                               }

        self.auto_ROI_ch_table_col1 = {'name': 'auto_ROI_ch_table_col1',
                                       'width': int(2 * self.PTU_DATA_window['width'] / 8)
                                       }
        self.auto_ROI_ch_table_col2 = {'name': 'auto_ROI_ch_table_col2',
                                       'width': int(3 * self.PTU_DATA_window['width'] / 8)
                                       }
        self.auto_ROI_ch_table_col3 = {'name': 'auto_ROI_ch_table_col3',
                                       'width': int(3 * self.PTU_DATA_window['width'] / 8)
                                       }
        self.ROI_mode_1 = {'name': 'ROI_mode_1',
                           'width': -1,
                           'items': self.ROI_mode_items

                           }
        self.ROI_mode_2 = {'name': 'ROI_mode_2',
                           'width': -1,
                           'items': self.ROI_mode_items

                           }
        self.file_box = {'name': 'file_box',
                         'width': -1,
                         'num_items': 15,
                         'items': self.files

                         }
        self.Calculate_button = {'name': 'Calculate_button',
                                 'width': -1

                                 }
        self.add_to_res_single_button = {'name': 'add_to_res_single_button',
                                         'width': -1

                                         }
        self.Calculate_all_button = {'name': 'Calculate_all_button',
                                     'width': -1

                                     }
        self.EXPORT_ops_table_col1 = {'name': 'EXPORT_ops_table_col1',
                                      'width': int(self.file_window['width'] / 2)
                                      }
        self.EXPORT_ops_table_col2 = {'name': 'EXPORT_ops_table_col2',
                                      'width': int(self.file_window['width'] / 2)
                                      }

        self.Export_all_button = {'name': 'Export_all_button',
                                  'width': -1

                                  }
        self.cell_thres_ratio_1 = {'name': 'cell_thres_ratio_1',
                                   'width': -1

                                   }

        self.nucl_thres_ratio_1 = {'name': 'nucl_thres_ratio_1',
                                   'width': -1

                                   }
        self.img_win_1_table_2_col1 = {'name': 'img_win_1_table_2_col1',
                                       'width': int(self.image_window_ch1['width'] / 3)
                                       }
        self.img_win_1_table_2_col2 = {'name': 'img_win_1_table_2_col2',
                                       'width': int(self.image_window_ch1['width'] / 3)
                                       }
        self.img_win_1_table_2_col3 = {'name': 'img_win_1_table_2_col3',
                                       'width': int(self.image_window_ch1['width'] / 3)
                                       }
        self.img_contrast_1 = {'name': 'img_contrast_1',
                               'width': -1

                               }
        self.img_Brightness_1 = {'name': 'img_Brightness_1',
                                 'width': -1

                                 }
        self.img_roi_alpha_1 = {'name': 'img_roi_alpha_1',
                                'width': -1

                                }
        self.cell_thres_ratio_2 = {'name': 'cell_thres_ratio_2',
                                   'width': -1

                                   }

        self.nucl_thres_ratio_2 = {'name': 'nucl_thres_ratio_2',
                                   'width': -1

                                   }
        self.img_win_2_table_2_col1 = {'name': 'img_win_2_table_2_col1',
                                       'width': int(self.image_window_ch2['width'] / 3)
                                       }
        self.img_win_2_table_2_col2 = {'name': 'img_win_2_table_2_col2',
                                       'width': int(self.image_window_ch2['width'] / 3)
                                       }
        self.img_win_2_table_2_col3 = {'name': 'img_win_2_table_2_col3',
                                       'width': int(self.image_window_ch2['width'] / 3)
                                       }
        self.img_contrast_2 = {'name': 'img_contrast_2',
                               'width': -1

                               }
        self.img_Brightness_2 = {'name': 'img_Brightness_2',
                                 'width': -1

                                 }
        self.img_roi_alpha_2 = {'name': 'img_roi_alpha_2',
                                'width': -1

                                }
        self.hist_conc_plot_ch1 = {'name': 'hist_conc_plot_ch1',
                                   'width': -1,
                                   'height': -1

                                   }
        self.hist_np_plot_ch1 = {'name': 'hist_np_plot_ch1',
                                 'width': -1,
                                 'height': -1

                                 }
        self.hist_phot_plot_ch1 = {'name': 'hist_phot_plot_ch1',
                                   'width': -1,
                                   'height': -1

                                   }
        self.hist_conc_plot_ch2 = {'name': 'hist_conc_plot_ch2',
                                   'width': -1,
                                   'height': -1

                                   }
        self.hist_np_plot_ch2 = {'name': 'hist_np_plot_ch2',
                                 'width': -1,
                                 'height': -1

                                 }
        self.hist_phot_plot_ch2 = {'name': 'hist_phot_plot_ch2',
                                   'width': -1,
                                   'height': -1

                                   }
        self.Load_calib_button = {'name': 'Load_calib_button',
                                  'width': -1

                                  }

        self.Save_calib_button = {'name': 'Save_calib_button',
                                  'width': -1

                                  }
        self.FCS_win_CH1_table_col1 = {'name': 'FCS_win_CH1_table_col1',
                                       'width': int(2 * self.FCS_window['width'] / 3)
                                       }
        self.FCS_win_CH1_table_col2 = {'name': 'FCS_win_CH1_table_col2',
                                       'width': int(self.FCS_window['width'] / 3)
                                       }
        self.omega_input_ch_1 = {'name': 'omega_input_ch_1',
                                 'width': -1

                                 }
        self.omega_err_input_ch_1 = {'name': 'omega_err_input_ch_1',
                                     'width': -1

                                     }

        self.kappa_input_ch_1 = {'name': 'kappa_input_ch_1',
                                 'width': -1

                                 }
        self.kappa_err_input_ch_1 = {'name': 'kappa_err_input_ch_1',
                                     'width': -1

                                     }

        self.focal_vol_input_ch_1 = {'name': 'focal_vol_input_ch_1',
                                     'width': -1

                                     }
        self.focal_vol_err_input_ch_1 = {'name': 'focal_vol_err_input_ch_1',
                                         'width': -1

                                         }
        self.Brightness_input_ch_1 = {'name': 'Brightness_input_ch_1',
                                      'width': -1,
                                      'default_value': 1000
                                      }
        self.Brightness_err_input_ch_1 = {'name': 'Brightness_err_input_ch_1',
                                          'width': -1,
                                          'default_value': 100
                                          }

        self.FCS_win_CH2_table_col1 = {'name': 'FCS_win_CH2_table_col1',
                                       'width': int(2 * self.FCS_window['width'] / 3)
                                       }
        self.FCS_win_CH2_table_col2 = {'name': 'FCS_win_CH2_table_col2',
                                       'width': int(self.FCS_window['width'] / 3)
                                       }
        self.omega_input_ch_2 = {'name': 'omega_input_ch_2',
                                 'width': -1

                                 }
        self.omega_err_input_ch_2 = {'name': 'omega_err_input_ch_2',
                                     'width': -1

                                     }

        self.kappa_input_ch_2 = {'name': 'kappa_input_ch_2',
                                 'width': -1

                                 }
        self.kappa_err_input_ch_2 = {'name': 'kappa_err_input_ch_2',
                                     'width': -1

                                     }

        self.focal_vol_input_ch_2 = {'name': 'focal_vol_input_ch_2',
                                     'width': -1

                                     }
        self.focal_vol_err_input_ch_2 = {'name': 'focal_vol_err_input_ch_2',
                                         'width': -1

                                         }
        self.Brightness_input_ch_2 = {'name': 'Brightness_input_ch_2',
                                      'width': -1,
                                      'default_value': 1000
                                      }
        self.Brightness_err_input_ch_2 = {'name': 'Brightness_err_input_ch_2',
                                          'width': -1,
                                          'default_value': 100
                                          }

        self.RES_win_CH1_table_col1 = {'name': 'RES_win_CH1_table_col1',
                                       'width': int(2 * self.FCS_window['width'] / 3)
                                       }
        self.RES_win_CH1_table_col2 = {'name': 'RES_win_CH1_table_col2',
                                       'width': int(self.FCS_window['width'] / 3)
                                       }

        self.sinle_phot_output_ch_1 = {'name': 'sinle_phot_output_ch_1',
                                       'width': -1

                                       }
        self.sinle_phot_err_output_ch_1 = {'name': 'sinle_phot_err_output_ch_1',
                                           'width': -1

                                           }
        self.sinle_mols_output_ch_1 = {'name': 'sinle_mols_output_ch_1',
                                       'width': -1

                                       }
        self.sinle_mols_err_output_ch_1 = {'name': 'sinle_mols_err_output_ch_1',
                                           'width': -1

                                           }

        self.single_conc_output_ch_1 = {'name': 'single_conc_output_ch_1',
                                        'width': -1

                                        }
        self.single_conc_err_output_ch_1 = {'name': 'single_conc_err_output_ch_1',
                                            'width': -1

                                            }
        self.RES_win_CH2_table_col1 = {'name': 'RES_win_CH2_table_col1',
                                       'width': int(2 * self.FCS_window['width'] / 3)
                                       }
        self.RES_win_CH2_table_col2 = {'name': 'RES_win_CH2_table_col2',
                                       'width': int(self.FCS_window['width'] / 3)
                                       }
        self.sinle_phot_output_ch_2 = {'name': 'sinle_phot_output_ch_2',
                                       'width': -1

                                       }
        self.sinle_phot_err_output_ch_2 = {'name': 'sinle_phot_err_output_ch_2',
                                           'width': -1

                                           }
        self.sinle_mols_output_ch_2 = {'name': 'sinle_mols_output_ch_2',
                                       'width': -1

                                       }
        self.sinle_mols_err_output_ch_2 = {'name': 'sinle_mols_err_output_ch_2',
                                           'width': -1

                                           }

        self.single_conc_output_ch_2 = {'name': 'single_conc_output_ch_2',
                                        'width': -1

                                        }
        self.single_conc_err_output_ch_2 = {'name': 'single_conc_err_output_ch_2',
                                            'width': -1

                                            }
        self.ROI_folder_dialog_id = {'name': 'ROI_folder_dialog_id',
                                     'width': int(900 * self.size_ratio['width']),
                                     'height': int(600 * self.size_ratio['width'])

                                     }
        self.file_dialog_id = {'name': 'file_dialog_id',
                               'width': int(900 * self.size_ratio['width']),
                               'height': int(600 * self.size_ratio['width'])

                               }
        self.PTU_file_dialog_id = {'name': 'PTU_file_dialog_id',
                                   'width': int(900 * self.size_ratio['width']),
                                   'height': int(600 * self.size_ratio['width'])

                                   }
        self.Select_ROI_dialog = {'name': 'Select_ROI_dialog',
                                  'width': int(900 * self.size_ratio['width']),
                                  'height': int(600 * self.size_ratio['width'])

                                  }
        self.file_dialog_export = {'name': 'file_dialog_export',
                                   'width': int(900 * self.size_ratio['width']),
                                   'height': int(600 * self.size_ratio['width'])

                                   }
        self.Calib_file_dialog_id = {'name': 'Calib_file_dialog_id',
                                     'width': int(900 * self.size_ratio['width']),
                                     'height': int(600 * self.size_ratio['width'])

                                     }

        self.ROI_names_combo_tag = {'name': 'ROI_names_combo_tag',
                                    'width': -1,
                                    'items': ['ROI_0']
                                    }

    def im_to_rgbim(self, im):
        '''Converts grayscale image into rgba(float) image.'''
        rgba_image = np.zeros((im.shape[0], im.shape[1], 4), dtype=np.float64)
        rgba_image[..., 0] = im
        rgba_image[..., 1] = im
        rgba_image[..., 2] = im
        rgba_image[..., 3] = 1

        return rgba_image


####################################################################
################### end of _Phot2conc_init class ###################
#################################################################### 

class _Phot2conc_vars_funct:
    def __init__(self,
                 INIT,
                 last_directory,
                 basf,
                 _globalITEMS):
        self.mode_init = INIT
        self.basf = basf
        self.last_directory = last_directory
        self._GI = _globalITEMS
        self.size_ratio = self.mode_init.size_ratio
        self.Sing_Results_DF = pd.DataFrame()
        self.initialize_res_df()
        self.anal_file = ''
        self.tex_1_name = self.mode_init.tex_1_name
        self.tex_2_name = self.mode_init.tex_2_name
        self.pck_list = []
        self.Channels = ''
        self.mean_Molecules_ch_1 = None
        self.std_Molecules_ch_1 = None
        self.mean_Concentration_ch_1 = None
        self.std_Concentration_ch_1 = None
        self.std_err_Concentration_ch_1 = None
        self.median_C_ch_1 = None
        self.median_err_C_ch_1 = None
        self.mean_Molecules_err_ch_1 = None
        self.mean_Concentration_err_ch_1 = None
        self.mean_Photons_ch_1 = None
        self.mean_Photons_err_ch_1 = None
        self.mean_Background_Photons_ch_1 = None
        self.mean_Background_Photons_err_ch_1 = None
        self.effective_pixels_ch_1 = np.nan
        self.mean_Molecules_ch_2 = None
        self.std_Molecules_ch_2 = None
        self.mean_Concentration_ch_2 = None
        self.std_Concentration_ch_2 = None
        self.std_err_Concentration_ch_2 = None
        self.median_C_ch_2 = None
        self.median_err_C_ch_2 = None
        self.mean_Molecules_err_ch_2 = None
        self.mean_Concentration_err_ch_2 = None
        self.mean_Photons_ch_2 = None
        self.mean_Photons_err_ch_2 = None
        self.mean_Background_Photons_ch_2 = None
        self.mean_Background_Photons_err_ch_2 = None
        self.effective_pixels_ch_2 = np.nan
        self.FCS_results_ch_1 = pd.DataFrame()
        self.FCS_results_ch_2 = pd.DataFrame()
        self.mean_brightness_err_ch_1 = 1
        self.mean_brightness_err_ch_2 = 1
        self.mean_brightness_ch_1 = 1
        self.mean_brightness_ch_2 = 1
        self.files = []
        self.pck_files = []
        self.PTU_directory = ''
        self.ROI_directory = ''
        self.calib_directory = ''
        self.sync_rate = None
        self.pixel_dwell = None
        self.number_of_frames = None
        self.DF = pd.DataFrame()
        self.DF2 = pd.DataFrame()
        self.PTU_N_frames = None
        self.PTU_Px_dwell = None
        self.PTU_Resolution = None
        self.PTU_Px_size = None
        self.image_1_times_roi = None
        self.image_2_times_roi = None
        self.pkl = None
        self.roi_1 = None
        self.roi_2 = None
        self.img_height_shift = {'name': 'img_height_shift',
                                 'shift': int(24 * self.size_ratio['height'])
                                 }
        self.NO_IMAGE_INTENSITY = self.mode_init.NO_IMAGE_INTENSITY
        self.processor_1 = self.mode_init.processor_1
        self.processor_2 = self.mode_init.processor_2
        self.display_option = 'Foreground intensity'
        self.decay_display_ranges = {'1': None, '2': None}
        self.decay_display_bounds = {'1': (0.0, 1.0), '2': (0.0, 1.0)}
        self.decay_display_offsets = {'1': 0.0, '2': 0.0}
        self.decay_display_is_pie = {'1': False, '2': False}
        self._attach_display_subprocessors(self.processor_1)
        self._attach_display_subprocessors(self.processor_2)
        self.Current_image_1 = self.processor_1.image
        self.Current_image_2 = self.processor_2.image
        self.pkl_data = None
        self.frame_results_by_channel = {}
        self.frame_results_file = None
        self.im_to_rgbim = self.mode_init.im_to_rgbim
        self.ROIS_state = {'File roi': False,
                           'Auto roi': {
                               'state': False,
                               'subs': {
                                   'cell_thres_ratio_1': 1.0,
                                   'nucl_thres_ratio_1': 1.5,
                                   'ROI_mode_1': '',
                                   'cp_roi_1': False,
                                   'cell_thres_ratio_2': 1.0,
                                   'nucl_thres_ratio_2': 1.5,
                                   'ROI_mode_2': '',
                                   'cp_roi_2': False,
                               }
                           }
                           }
        self.DialWinList = []
        self.up_key = dpg.mvKey_Up
        self.down_key = dpg.mvKey_Down
        self.active_keys = [dpg.mvKey_Up,
                            dpg.mvKey_Down]

    @staticmethod
    def _attach_display_subprocessors(processor, background_image=None, decay_time_image=None):
        """Attach non-foreground image processors to a foreground processor."""
        reference_image = np.asarray(processor.image, dtype=np.float64)
        if background_image is None:
            background_image = np.zeros_like(reference_image)
        if decay_time_image is None:
            decay_time_image = np.zeros_like(reference_image)

        processor.background = ImageROIProcessor()
        processor.background.image = np.asarray(background_image)
        processor.decay_time = ImageROIProcessor()
        processor.decay_time.image = np.asarray(decay_time_image)

    @staticmethod
    def _calculation_intensity(image):
        """Return an analysis image without discarding fractional photon weights."""
        return np.asarray(image, dtype=np.float32)

    def _ensure_display_subprocessors(self):
        """Attach current PKL products after a foreground processor is replaced."""
        pkl_data = self.pkl_data if isinstance(self.pkl_data, dict) else {}
        for channel in ('1', '2'):
            foreground_processor = getattr(self, f'processor_{channel}')
            if hasattr(foreground_processor, 'background') and hasattr(foreground_processor, 'decay_time'):
                continue
            self._attach_display_subprocessors(
                foreground_processor,
                background_image=pkl_data.get(
                    f'bgrnd_{channel}',
                    np.zeros_like(foreground_processor.image, dtype=np.float64),
                ),
                decay_time_image=pkl_data.get(
                    f'lifetimes_{channel}',
                    np.zeros_like(foreground_processor.image, dtype=np.float64),
                ),
            )
            self._synchronize_display_roi(channel)

    @staticmethod
    def _decay_time_limits(image):
        """Return the finite, positive decay-time range in nanoseconds."""
        numeric_image = np.asarray(image, dtype=np.float64)
        valid_values = numeric_image[np.isfinite(numeric_image) & (numeric_image > 0)]
        if valid_values.size == 0:
            return 0.0, 1.0
        return float(np.min(valid_values)), float(np.max(valid_values))

    def _initialize_decay_display_ranges(self):
        """Derive display-only lifetime ranges from PKL axes and detect PIE gates."""
        pkl_data = self.pkl_data if isinstance(self.pkl_data, dict) else {}
        lifetime_resolution = float(
            pkl_data.get('File info', {}).get('Lifetime resolution', 1.0)
        )
        pie_spans = []

        for channel in ('1', '2'):
            lifetime_image = pkl_data.get(f'lifetimes_{channel}', np.zeros((1, 1)))
            data_lower, data_upper = self._decay_time_limits(lifetime_image)
            tau_table = pkl_data.get(f'taus_{channel}')
            full_tau_table = pkl_data.get(f'fulltaus_{channel}')
            is_pie = (
                isinstance(tau_table, pd.DataFrame)
                and isinstance(full_tau_table, pd.DataFrame)
                and 'Tau' in tau_table
                and len(tau_table) > 1
                and len(tau_table) < len(full_tau_table)
            )

            if is_pie:
                tau_values = np.asarray(tau_table['Tau'], dtype=np.float64)
                offset = float(np.nanmin(tau_values) * lifetime_resolution)
                span = float((np.nanmax(tau_values) - np.nanmin(tau_values)) * lifetime_resolution)
                if not np.isfinite(span) or span <= 0:
                    span = max(data_upper - offset, lifetime_resolution)
                self.decay_display_offsets[channel] = offset
                self.decay_display_is_pie[channel] = True
                pie_spans.append(span)
                self.decay_display_bounds[channel] = (0.0, span)
                self.decay_display_ranges[channel] = (0.0, span)
            else:
                if data_upper <= data_lower:
                    data_upper = data_lower + max(lifetime_resolution, 1e-9)
                self.decay_display_offsets[channel] = 0.0
                self.decay_display_is_pie[channel] = False
                self.decay_display_bounds[channel] = (data_lower, data_upper)
                self.decay_display_ranges[channel] = (data_lower, data_upper)

        if pie_spans:
            common_span = max(pie_spans)
            for channel in ('1', '2'):
                if self.decay_display_is_pie[channel]:
                    self.decay_display_bounds[channel] = (0.0, common_span)
                    self.decay_display_ranges[channel] = (0.0, common_span)

    def _decay_display_range(self, channel, image):
        """Return display limits and the visual PIE offset for one channel."""
        if channel in ('1', '2') and self.decay_display_ranges[channel] is not None:
            return (
                self.decay_display_ranges[channel],
                self.decay_display_offsets[channel],
            )
        return self._decay_time_limits(image), 0.0

    def _normalized_display_image(self, image, intensity_reference=None, channel=None):
        """Normalize a finite image for display without changing analysis values."""
        numeric_image = np.asarray(image, dtype=np.float64)
        if self.display_option == 'Foreground decay times':
            valid_mask = np.isfinite(numeric_image) & (numeric_image > 0)
            normalized = np.zeros_like(numeric_image, dtype=np.float64)
            if not np.any(valid_mask):
                return normalized
            (lower_limit, upper_limit), display_offset = self._decay_display_range(channel, numeric_image)
            displayed_values = numeric_image[valid_mask] - display_offset
            if upper_limit > lower_limit:
                scaled = np.clip(
                    (displayed_values - lower_limit) / (upper_limit - lower_limit),
                    0,
                    1,
                )
                normalized[valid_mask] = (1.0 + 254.0 * scaled) / 255.0
            else:
                normalized[valid_mask] = 1.0
            return normalized

        finite_image = np.nan_to_num(numeric_image, nan=0.0, posinf=0.0, neginf=0.0)
        normalization_image = finite_image
        if self.display_option == 'Background intensity' and intensity_reference is not None:
            normalization_image = np.nan_to_num(
                np.asarray(intensity_reference, dtype=np.float64),
                nan=0.0,
                posinf=0.0,
                neginf=0.0,
            )
        image_maximum = np.max(normalization_image) if normalization_image.size else 0.0
        if image_maximum <= 0:
            return np.zeros_like(finite_image, dtype=np.float64)
        return np.clip(finite_image / image_maximum, 0, 1)

    def _display_rgba(self, normalized_image):
        """Render decay times with Viridis and other image products in grayscale."""
        if self.display_option != 'Foreground decay times':
            return self.im_to_rgbim(normalized_image)

        indexed_image = np.rint(np.clip(normalized_image, 0, 1) * 255).astype(np.uint8)
        colored_bgr = cv2.applyColorMap(indexed_image, cv2.COLORMAP_VIRIDIS)
        colored_rgb = cv2.cvtColor(colored_bgr, cv2.COLOR_BGR2RGB).astype(np.float64) / 255.0
        colored_rgb[indexed_image == 0] = 0.0
        rgba_image = np.ones((*indexed_image.shape, 4), dtype=np.float64)
        rgba_image[..., :3] = colored_rgb
        return rgba_image

    def _update_decay_color_scales(self):
        """Show channel-specific decay-time scales and keep their limits current."""
        show_scales = self.display_option == 'Foreground decay times'
        self._ensure_display_subprocessors()
        for channel in ('1', '2'):
            dpg.configure_item(f'decay_scale_group_ch_{channel}', show=show_scales)
        if not show_scales:
            return

        for channel in ('1', '2'):
            decay_image = getattr(self, f'processor_{channel}').decay_time.image
            (lower_limit, upper_limit), _ = self._decay_display_range(channel, decay_image)
            middle_value = (lower_limit + upper_limit) / 2
            bounds_lower, bounds_upper = self.decay_display_bounds[channel]
            control_speed = max((bounds_upper - bounds_lower) / 200, 0.001)
            dpg.configure_item(f'decay_scale_min_ch_{channel}', text=f'{lower_limit:.4g}')
            dpg.configure_item(f'decay_scale_mid_ch_{channel}', text=f'{middle_value:.4g}')
            dpg.configure_item(f'decay_scale_max_ch_{channel}', text=f'{upper_limit:.4g}')
            for boundary in ('min', 'max'):
                dpg.configure_item(
                    f'decay_range_{boundary}_ch_{channel}',
                    min_value=bounds_lower,
                    max_value=bounds_upper,
                    speed=control_speed,
                )
            dpg.set_value(f'decay_range_min_ch_{channel}', lower_limit)
            dpg.set_value(f'decay_range_max_ch_{channel}', upper_limit)

    def callback_decay_time_range(self, sender, app_data, user_data):
        """Update the visible lifetime color interval without modifying PKL values."""
        channel = str(user_data)
        lower_limit = float(dpg.get_value(f'decay_range_min_ch_{channel}'))
        upper_limit = float(dpg.get_value(f'decay_range_max_ch_{channel}'))
        bounds_lower, bounds_upper = self.decay_display_bounds[channel]
        minimum_step = max((bounds_upper - bounds_lower) / 1000, 1e-9)

        if lower_limit >= upper_limit:
            if sender == f'decay_range_min_ch_{channel}':
                lower_limit = max(bounds_lower, upper_limit - minimum_step)
                dpg.set_value(sender, lower_limit)
            else:
                upper_limit = min(bounds_upper, lower_limit + minimum_step)
                dpg.set_value(sender, upper_limit)

        self.decay_display_ranges[channel] = (lower_limit, upper_limit)
        self._update_decay_color_scales()
        if channel in self.Channels:
            self.process_channel(channel, self.get_ui_state(channel))

    def _get_display_processor(self, channel):
        """Return the selected image subprocessor for a channel."""
        foreground_processor = getattr(self, f'processor_{channel}')
        if self.display_option == 'Background intensity':
            return getattr(foreground_processor, 'background', foreground_processor)
        if self.display_option == 'Foreground decay times':
            return getattr(foreground_processor, 'decay_time', foreground_processor)
        return foreground_processor

    def _synchronize_display_roi(self, channel):
        """Expose foreground ROI state to both image subprocessors."""
        foreground_processor = getattr(self, f'processor_{channel}')
        for display_processor in (
            getattr(foreground_processor, 'background', foreground_processor),
            getattr(foreground_processor, 'decay_time', foreground_processor),
        ):
            display_processor.roi_image = foreground_processor.roi_image
            display_processor.all_masks = foreground_processor.all_masks
            display_processor.all_contours = foreground_processor.all_contours
            display_processor.all_cells_masks = foreground_processor.all_cells_masks
            display_processor.all_cells_contours = foreground_processor.all_cells_contours

    def callback_DISP_OPT_combo(self, sender, app_data):
        """Switch image products while retaining foreground-derived ROI masks."""
        self.display_option = app_data or dpg.get_value('DISP_OPT_combo')
        show_decay_options = self.display_option == 'Foreground decay times'
        show_photon_results = not show_decay_options
        show_converted_results = self.display_option == 'Foreground intensity'
        self._update_decay_color_scales()
        histogram_label = (
            'Background photons per pixel distribution'
            if self.display_option == 'Background intensity'
            else 'Photons per pixel distribution'
        )
        for channel in ('1', '2'):
            dpg.configure_item(f'phot_dist_ser_ch_{channel}', label=histogram_label)
            dpg.configure_item(
                f'RES_win_CH{channel}_table_row1',
                show=show_photon_results,
            )
            for row_number in ('2', '3'):
                dpg.configure_item(
                    f'RES_win_CH{channel}_table_row{row_number}',
                    show=show_converted_results,
                )
        for channel in ('1', '2'):
            self._synchronize_display_roi(channel)
            display_processor = self._get_display_processor(channel)
            setattr(
                self,
                f'Current_image_{channel}',
                self._normalized_display_image(
                    display_processor.image,
                    getattr(self, f'processor_{channel}').image,
                    channel,
                ),
            )
        self.display_images('both')

    def get_roi_state(self):
        self.ROIS_state = {'File roi': dpg.get_value('FILE_ROI_checkbox'),
                           'Auto roi': {
                               'state': dpg.get_value('Auto_ROI_checkbox'),
                               'subs': {
                                   'cell_thres_ratio_1': dpg.get_value('cell_thres_ratio_1'),
                                   'nucl_thres_ratio_1': dpg.get_value('nucl_thres_ratio_1'),
                                   'ROI_mode_1': dpg.get_value('ROI_mode_1'),
                                   'cp_roi_1': dpg.get_value('cp_roi_1'),
                                   'cell_thres_ratio_2': dpg.get_value('cell_thres_ratio_2'),
                                   'nucl_thres_ratio_2': dpg.get_value('nucl_thres_ratio_2'),
                                   'ROI_mode_2': dpg.get_value('ROI_mode_2'),
                                   'cp_roi_2': dpg.get_value('cp_roi_2'),
                               }
                           }
                           }

    def set_roi_state(self):
        dpg.set_value('FILE_ROI_checkbox', self.ROIS_state['File roi'])
        dpg.set_value('Auto_ROI_checkbox', self.ROIS_state['Auto roi']['state'])
        for key in self.ROIS_state['Auto roi']['subs'].keys():
            dpg.set_value(key, self.ROIS_state['Auto roi']['subs'][key])

    def define_file_menu_callbacks(self):

        dpg.configure_item('Open_PTU_menu_item', callback=lambda: dpg.show_item("PTU_file_dialog_id"))
        dpg.configure_item('Open_ROI_menu_item', callback=lambda: dpg.show_item("ROI_folder_dialog_id"))
        dpg.configure_item('Reset_results_menu_item', callback=self.callback_reset_results_DF)

    
    def VEFF(self, w, k, w_err, k_err):
        V = (pi ** (3 / 2)) * (w ** 3) * k
        V_err = sqrt(9 * (k ** 2) * (pi ** 3) * (w ** 4) * (w_err ** 2) + (k_err ** 2) * (pi ** 3) * (w ** 6))
        return V, V_err

    def CONC(self, N, V, N_err, V_err):
        Na = constants.N_A
        C = N / (Na * V)
        C_err = sqrt(((N ** 2) * (V_err ** 2)) / ((Na ** 2) * (V ** 4)) + (N_err ** 2) / ((Na ** 2) * (V ** 2)))
        return C, C_err

    def Export_result_dataframe_to_file(self, sender, app_data):
        self.directory = app_data['current_path']
        self.new_directory = self.directory
        self.last_directory = self.directory
        self.update_dialogs_default_directory(self.last_directory)
        filtr = app_data['current_filter']
        if filtr == '':
            fnam = app_data['file_name']
            filtr = '.' + fnam.split('.')[1]
            
        elif filtr == '.dat':
            path = app_data['file_path_name']
            self.Sing_Results_DF.to_csv(path, sep='\t', index=False)

        elif filtr == '.csv':
            path = app_data['file_path_name']
            self.Sing_Results_DF.to_csv(path, index=False)

        else:
            path = app_data['file_path_name']
            self.Sing_Results_DF.to_pickle(path)

    def Exception(self, tried):
        function_name = sys._getframe(0).f_code.co_name
        print('Exception in function ' + str(function_name) + ' while trying: ' + tried)

    def Load_Save_Calib_file(self, sender, app_data, user_data):
        self.directory = app_data['current_path']
        self.new_directory = self.directory
        self.last_directory = self.directory
        self.update_dialogs_default_directory(self.last_directory)

        if user_data == 'Load_calib_button':
            path_to_json_file = app_data['file_path_name']
            calib_directory = path_to_json_file

            with open(path_to_json_file) as json_file:
                data = json.load(json_file)
            json_file.close()

            for k0 in data.keys():
                try:
                    len_kappa = len(data[k0]['kappa'])
                except:
                    self.Exception("len_kappa = len(data[k0]['kappa'])")

                try:
                    len_omega = len(data[k0]['omega'])
                except:
                    self.Exception("len_omega = len(data[k0]['omega'])")

                try:
                    len_V0 = len(data[k0]['V0'])
                except:
                    self.Exception("len_V0= len(data[k0]['V0'])")

                try:
                    len_Bright = len(data[k0]['Mol.Brightness'])
                except:
                    self.Exception("len_Bright= len(data[k0]['Mol.Brightness'])")

                if (len_kappa == 2) and (len_omega == 2) and (len_V0 == 2) and (len_Bright == 2):

                    if k0 == 'Channel_1':
                        dpg.set_value('omega_input_ch_1', data[k0]['omega'][0])
                        dpg.set_value('omega_err_input_ch_1', data[k0]['omega'][1])
                        dpg.set_value('kappa_input_ch_1', data[k0]['kappa'][0])
                        dpg.set_value('kappa_err_input_ch_1', data[k0]['kappa'][1])
                        Vf = self.VEFF(data[k0]['omega'][0], data[k0]['kappa'][0], data[k0]['omega'][1], data[k0]['kappa'][1])
                        dpg.set_value('focal_vol_input_ch_1', Vf[0])
                        dpg.set_value('focal_vol_err_input_ch_1', Vf[1])
                        dpg.set_value('Brightness_input_ch_1', data[k0]['Mol.Brightness'][0])
                        dpg.set_value('Brightness_err_input_ch_1', data[k0]['Mol.Brightness'][1])

                    elif k0 == 'Channel_2':

                        dpg.set_value('omega_input_ch_2', data[k0]['omega'][0])
                        dpg.set_value('omega_err_input_ch_2', data[k0]['omega'][1])
                        dpg.set_value('kappa_input_ch_2', data[k0]['kappa'][0])
                        dpg.set_value('kappa_err_input_ch_2', data[k0]['kappa'][1])
                        Vf = self.VEFF(data[k0]['omega'][0], data[k0]['kappa'][0], data[k0]['omega'][1], data[k0]['kappa'][1])
                        dpg.set_value('focal_vol_input_ch_2', Vf[0])
                        dpg.set_value('focal_vol_err_input_ch_2', Vf[1])
                        dpg.set_value('Brightness_input_ch_2', data[k0]['Mol.Brightness'][0])
                        dpg.set_value('Brightness_err_input_ch_2', data[k0]['Mol.Brightness'][1])

                    else:
                        pass
                elif (len_kappa == 0) and (len_omega == 0) and (len_V0 == 0) and (len_Bright == 0):
                    pass

                else:
                    pass

        elif user_data == 'Save_calib_button':
            path_to_json_file = app_data['file_path_name']
            calib_directory = path_to_json_file
            omega_1 = [dpg.get_value('omega_input_ch_1'), dpg.get_value('omega_err_input_ch_1')]
            kappa_1 = [dpg.get_value('kappa_input_ch_1'), dpg.get_value('kappa_err_input_ch_1')]
            V0_1 = [dpg.get_value('focal_vol_input_ch_1'), dpg.get_value('focal_vol_err_input_ch_1')]
            bright_1 = [dpg.get_value('Brightness_input_ch_1'), dpg.get_value('Brightness_err_input_ch_1')]
            omega_2 = [dpg.get_value('omega_input_ch_2'), dpg.get_value('omega_err_input_ch_2')]
            kappa_2 = [dpg.get_value('kappa_input_ch_2'), dpg.get_value('kappa_err_input_ch_2')]
            V0_2 = [dpg.get_value('focal_vol_input_ch_2'), dpg.get_value('focal_vol_err_input_ch_2')]
            bright_2 = [dpg.get_value('Brightness_input_ch_2'), dpg.get_value('Brightness_err_input_ch_2')]
            output_dict = {'Channel_1': {'omega': omega_1,
                                         'kappa': kappa_1,
                                         'V0': V0_1,
                                         'Mol.Brightness': bright_1
                                         },
                           'Channel_2': {'omega': omega_2,
                                         'kappa': kappa_2,
                                         'V0': V0_2,
                                         'Mol.Brightness': bright_2
                                         }
                           }

            with open(path_to_json_file, 'w') as f:
                json.dump(output_dict, f, indent=4, sort_keys=False)

    def add_single_result_to_DF(self, sender, app_data):
        stored_results = self.Sing_Results_DF.File.values
        if self.anal_file in stored_results:
            for index, row in self.Sing_Results_DF.iterrows():
                if row['File'] == self.anal_file and row['ROI_name'] == dpg.get_value('ROI_name_tag'):
                    self.Sing_Results_DF.at[index, 'File'] = np.nan
                    self.Sing_Results_DF.at[index, 'ROI_name'] = np.nan

            self.Sing_Results_DF.dropna(
                subset=['File', 'ROI_name'],
                inplace=True,
            )
        else:
            pass

        if dpg.get_value('Auto_ROI_checkbox'):
            roiname = dpg.get_value('ROI_name_tag')
        elif dpg.get_value('FILE_ROI_checkbox'):
            roiname = dpg.get_value('ROI_names_combo_tag')
        else:
            roiname = dpg.get_value('ROI_name_tag')
        if len(self.Channels) == 1:

            if '1' in self.Channels[0]:
                self.Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                          roiname,
                                                          1,
                                                          self.mean_Photons_ch_1,
                                                          self.mean_Photons_err_ch_1,
                                                          self.mean_Molecules_ch_1,
                                                          self.mean_Molecules_err_ch_1,
                                                          self.mean_Concentration_ch_1,
                                                          self.mean_Concentration_err_ch_1,
                                                          self.median_C_ch_1,
                                                          self.median_err_C_ch_1,
                                                          self.mean_Background_Photons_ch_1,
                                                          self.mean_Background_Photons_err_ch_1
                                                          ]],
                                                        columns=self._base_result_columns())
            elif '2' in self.Channels[0]:
                self.Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                          roiname,
                                                          2,
                                                          self.mean_Photons_ch_2,
                                                          self.mean_Photons_err_ch_2,
                                                          self.mean_Molecules_ch_2,
                                                          self.mean_Molecules_err_ch_2,
                                                          self.mean_Concentration_ch_2,
                                                          self.mean_Concentration_err_ch_2,
                                                          self.median_C_ch_2, self.median_err_C_ch_2,
                                                          self.mean_Background_Photons_ch_2,
                                                          self.mean_Background_Photons_err_ch_2
                                                          ]],
                                                        columns=self._base_result_columns())
            else:
                pass
        if len(self.Channels) == 2:
            self.Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                      roiname,
                                                      1,
                                                      self.mean_Photons_ch_1,
                                                      self.mean_Photons_err_ch_1,
                                                      self.mean_Molecules_ch_1,
                                                      self.mean_Molecules_err_ch_1,
                                                      self.mean_Concentration_ch_1,
                                                      self.mean_Concentration_err_ch_1,
                                                      self.median_C_ch_1,
                                                      self.median_err_C_ch_1,
                                                      self.mean_Background_Photons_ch_1,
                                                      self.mean_Background_Photons_err_ch_1],
                                                     [self.anal_file,
                                                      roiname,
                                                      2,
                                                      self.mean_Photons_ch_2,
                                                      self.mean_Photons_err_ch_2,
                                                      self.mean_Molecules_ch_2,
                                                      self.mean_Molecules_err_ch_2,
                                                      self.mean_Concentration_ch_2,
                                                      self.mean_Concentration_err_ch_2,
                                                      self.median_C_ch_2, self.median_err_C_ch_2,
                                                      self.mean_Background_Photons_ch_2,
                                                      self.mean_Background_Photons_err_ch_2
                                                      ]], columns=self._base_result_columns())

        self.Sing_Results_DF_tmp = self._attach_frame_results(
            self.Sing_Results_DF_tmp
        )
        self.Sing_Results_DF = pd.concat([self.Sing_Results_DF,
                                          self.Sing_Results_DF_tmp]).reset_index(drop=True)
        self._pkl_file()

    def calc_molecules(self, DF, PTU_Px_dwell, PTU_N_frames, brightness, brightness_err):

        PTU_Px_dwell = PTU_Px_dwell * 1e-6
        MOL = (DF * (1 / (PTU_Px_dwell * PTU_N_frames))) / brightness
        part_BR = -DF / (PTU_N_frames * PTU_Px_dwell * (brightness ** 2))
        MOL_err = sqrt((part_BR ** 2) * (brightness_err ** 2))
        return MOL, MOL_err

    def callback_Brightness_err_input(self, sender, app_data):

        if sender == 'Brightness_err_input_ch_1':
            self.mean_brightness_err_ch_1 = app_data
            self.FCS_results_ch_1 = pd.DataFrame()

            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_1_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass

            try:
                dpg.delete_item('column_results_show_del_ch_1')
                dpg.delete_item('column_results_show_Brightness_ch_1')
                dpg.delete_item('column_results_show_N_p_ch_1')
                dpg.delete_item('column_results_show_file_ch_1')
                dpg.delete_item('table_results_show_ch_1')
                dpg.delete_item('remove_button_results_ch_1')
                dpg.delete_item('close_button_results_ch_1')
                dpg.delete_item('group_close_results_table_ch_1')
                dpg.delete_item('show_TT_res_win_ch_1')
            except:
                pass
        elif sender == 'Brightness_err_input_ch_2':
            mean_brightness_err_ch_2 = app_data
            FCS_results_ch_2 = pd.DataFrame()

            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_2_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass

            try:
                dpg.delete_item('column_results_show_del_ch_2')
                dpg.delete_item('column_results_show_Brightness_ch_2')
                dpg.delete_item('column_results_show_N_p_ch_2')
                dpg.delete_item('column_results_show_file_ch_2')
                dpg.delete_item('table_results_show_ch_2')
                dpg.delete_item('remove_button_results_ch_2')
                dpg.delete_item('close_button_results_ch_2')
                dpg.delete_item('group_close_results_table_ch_2')
                dpg.delete_item('show_TT_res_win_ch_2')
            except:
                pass
        else:
            pass

    def callback_Brightness_input(self, sender, app_data):

        if sender == 'Brightness_input_ch_1':
            self.mean_brightness_ch_1 = app_data
            self.FCS_results_ch_1 = pd.DataFrame()

            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_1_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            try:
                dpg.delete_item('column_results_show_del_ch_1')
                dpg.delete_item('column_results_show_Brightness_ch_1')
                dpg.delete_item('column_results_show_N_p_ch_1')
                dpg.delete_item('column_results_show_file_ch_1')
                dpg.delete_item('table_results_show_ch_1')
                dpg.delete_item('remove_button_results_ch_1')
                dpg.delete_item('close_button_results_ch_1')
                dpg.delete_item('group_close_results_tabl_ch_1')
                dpg.delete_item('show_TT_res_win_ch_1')
            except:
                pass
        elif sender == 'Brightness_input_ch_2':
            self.mean_brightness_ch_2 = app_data
            self.FCS_results_ch_2 = pd.DataFrame()

            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_2_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            try:
                dpg.delete_item('column_results_show_del_ch_2')
                dpg.delete_item('column_results_show_Brightness_ch_2')
                dpg.delete_item('column_results_show_N_p_ch_2')
                dpg.delete_item('column_results_show_file_ch_2')
                dpg.delete_item('table_results_show_ch_2')
                dpg.delete_item('remove_button_results_ch_2')
                dpg.delete_item('close_button_results_ch_2')
                dpg.delete_item('group_close_results_tabl_ch_2')
                dpg.delete_item('show_TT_res_win_ch_2')
            except:
                pass

        else:
            pass

    def callback_Keyword_key(self, sender, app_data):
        files = dpg.get_item_configuration('file_box')['items']
        up_key = dpg.mvKey_Up
        down_key = dpg.mvKey_Down

        if len(files) != 0:
            def_val = dpg.get_value('file_box')
            index = files.index(def_val)

            if app_data == up_key:
                if index != 0:
                    index = index - 1
                    dpg.set_value('file_box', files[index])
                    self.callback_listbox('file_box', files[index])
                else:
                    pass
            if app_data == down_key:
                if index != len(files) - 1:
                    index = index + 1
                    dpg.set_value('file_box', files[index])
                    self.callback_listbox('file_box', files[index])
                else:
                    pass

    def initialize_res_df(self):
        self.Sing_Results_DF = pd.DataFrame(columns=self._base_result_columns())

    def callback_PTU_directory_select(self, sender, app_data):

        self.initialize_res_df()
        self.files = ()
        dpg.set_value('FILE_ROI_checkbox', False)
        self.directory = app_data['file_path_name']
        self.new_directory = self.directory
        self.PTU_directory = self.directory
        self.last_directory = self.directory
        self.update_dialogs_default_directory(self.last_directory)
        self.files = tuple(np.sort([f for f in os.listdir(self.PTU_directory) if f.endswith('.ptu')]))
        self.pck_files = list(np.sort([f for f in os.listdir(self.PTU_directory) if f.endswith('.pkl')]))
        dpg.configure_item('FILE_ROI_checkbox', enabled=True)
        dpg.configure_item('Auto_ROI_checkbox', enabled=True)

        try:
            self.hide_histograms()
        except:
            pass

        filenames = [f.replace('.ptu', '') for f in self.files]

        if len(self.files) == 0:
            self.show_error_no_files('No PTU files found.')
        else:
            stop = False
            for file in filenames:
                ptufile = file + '.ptu'
                for f in self.pck_files:
                    if file in f:
                        stop = True
                        ffile = file
                        break
                    else:
                        stop = False

                if stop:
                    pass
                else:
                    self.show_error_no_files(
                        'No .pck files found. Run the EXTRACT_AND_FILTER_PTU.py script and try again. Mising file: ' + ffile)
                    try:
                        pass

                    except:
                        pass

        if len(self.pck_files) != 0:
            self.update_flist(filenames)
            self.anal_file = filenames[0]
            dpg.configure_item('file_box', default_value=self.anal_file)
            self.callback_listbox('file_box', self.anal_file)
            
        else:
            self.show_error_no_files('No .pck files found. Run the EXTRACT_AND_FILTER_PTU.py script and try again.')

    def callback_ROI_directory_select(self, sender, app_data):
        self.ROI_directory = app_data['file_path_name']
        self.last_directory = self.ROI_directory
        self.update_dialogs_default_directory(self.last_directory)
        dpg.set_value('FILE_ROI_checkbox', True)
        self.callback_select_roi('FILE_ROI_checkbox', True)
        dpg.hide_item('ROI_folder_dialog_id')
        self.load_PTU_images(self.anal_file)

    def callback_add_ROI(self, sender, app_data):

        dpg.configure_item("Select_ROI_dialog", user_data=sender)
        dpg.show_item("Select_ROI_dialog")

    def export_auto_roi(self,channel,ROI_array):
        folder_path = os.path.join(self.PTU_directory,'ROI')
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            
        else:
            pass
        
        roiname= dpg.get_value('ROI_name_tag').replace('ROI_','')
        
        fname = self.anal_file+'_roi'+roiname+'_ch_'+channel+'.tmp'
        df=pd.DataFrame(ROI_array)
        df = df.where(df!=0,'-')
        df.to_csv(os.path.join(folder_path,fname), index=False, sep='\t', header=None)
        output_roi_fname = os.path.join(folder_path,fname.replace('.tmp','.dat'))
        f = open(output_roi_fname,'w')
        f.write("Events[Cnts]\n")
        f.write("(x0 | y0) = (0.000[um] | 0.000[um])\n")
        f.write("(x1 | y1) = (??.???[um] | ??.???[um])\n")
        f.close()
        with open(os.path.join(folder_path,fname)) as reader:
            red_file = reader.read()
            reader.close()
        f = open(output_roi_fname, "a")
        f.write(red_file)
        f.close()
        tmp_files = os.listdir(folder_path)
        tmp_files = [f for f in tmp_files if f.endswith('.tmp')]
        for tmp in tmp_files:
            os.remove(os.path.join(folder_path,tmp))

    @staticmethod
    def _mean_and_sem(image):
        """Return the mean and SEM for finite pixels in an ROI image."""
        finite_values = np.asarray(image, dtype=np.float64)
        finite_values = finite_values[np.isfinite(finite_values)]
        if finite_values.size == 0:
            return np.nan, np.nan
        mean_value = float(np.mean(finite_values))
        if finite_values.size == 1:
            return mean_value, 0.0
        standard_error = float(np.std(finite_values, ddof=1) / sqrt(finite_values.size))
        return mean_value, standard_error

    @staticmethod
    def _effective_pixel_count(image, pixel_size_nm, omega_um):
        """Return the effective sample size for a Gaussian-overlap ROI.

        The normalized lateral overlap of two confocal observation profiles is
        modelled as exp(-d**2 / omega**2). The ROI-mask autocorrelation supplies
        the number of pixel pairs at every displacement without constructing an
        O(N**2) distance matrix.
        """
        mask = np.isfinite(np.asarray(image, dtype=np.float64))
        pixel_count = int(np.count_nonzero(mask))
        if pixel_count <= 1:
            return float(pixel_count)

        try:
            pixel_size_um = float(pixel_size_nm) * 1e-3
            omega_um = float(omega_um)
        except (TypeError, ValueError):
            return float(pixel_count)
        if not np.isfinite(pixel_size_um) or not np.isfinite(omega_um):
            return float(pixel_count)
        if pixel_size_um <= 0 or omega_um <= 0:
            return float(pixel_count)

        pair_counts = fftconvolve(
            mask.astype(np.float64),
            mask[::-1, ::-1].astype(np.float64),
            mode='full',
        )
        pair_counts = np.maximum(pair_counts, 0.0)
        row_offsets = (
            np.arange(-(mask.shape[0] - 1), mask.shape[0], dtype=np.float64)
            * pixel_size_um
        )
        column_offsets = (
            np.arange(-(mask.shape[1] - 1), mask.shape[1], dtype=np.float64)
            * pixel_size_um
        )
        squared_distance = (
            row_offsets[:, np.newaxis] ** 2
            + column_offsets[np.newaxis, :] ** 2
        )
        overlap = np.exp(-squared_distance / omega_um ** 2)
        correlation_sum = float(np.sum(pair_counts * overlap))
        if not np.isfinite(correlation_sum) or correlation_sum <= 0:
            return float(pixel_count)

        effective_count = pixel_count ** 2 / correlation_sum
        return float(np.clip(effective_count, 1.0, pixel_count))

    @staticmethod
    def _mean_and_effective_sem(image, effective_count):
        """Return the finite-pixel mean and correlation-corrected SEM."""
        finite_values = np.asarray(image, dtype=np.float64)
        finite_values = finite_values[np.isfinite(finite_values)]
        if finite_values.size == 0:
            return np.nan, np.nan
        mean_value = float(np.mean(finite_values))
        if finite_values.size == 1:
            return mean_value, 0.0
        effective_count = float(np.clip(effective_count, 1.0, finite_values.size))
        effective_sem = float(
            np.std(finite_values, ddof=1) / sqrt(effective_count)
        )
        return mean_value, effective_sem

    @classmethod
    def _reported_mean_error(
            cls, image, calibration_error_image, effective_count, sem_only):
        """Combine effective SEM with a shared calibration uncertainty."""
        _, effective_sem = cls._mean_and_effective_sem(image, effective_count)
        if sem_only or calibration_error_image is None:
            return effective_sem
        calibration_values = cls._finite_values(calibration_error_image)
        if calibration_values.size == 0:
            return effective_sem
        calibration_error = float(np.mean(calibration_values))
        return float(np.hypot(effective_sem, calibration_error))

    @staticmethod
    def _base_result_columns():
        return [
            'File',
            'ROI_name',
            'Channel',
            '<Counts>',
            'Counts_std',
            '<N_p>',
            'N_p_err',
            '<C>',
            'C_err',
            'C_median',
            'C_median_abs_err',
            '<Background counts>',
            'Background_counts_std',
        ]

    def _frame_roi_multiplier(self, channel, image_shape):
        '''Return the current foreground ROI without changing GUI state.'''

        processor = getattr(self, f'processor_{channel}')
        masks = getattr(processor, 'all_masks', None)
        if dpg.get_value('Auto_ROI_checkbox') and masks is not None and len(masks):
            multiplier = np.where(np.asarray(masks[0]) == 0, np.nan, 1.0)
        elif dpg.get_value('FILE_ROI_checkbox') and processor.roi_image is not None:
            multiplier = np.asarray(processor.roi_image, dtype=np.float64)
        else:
            multiplier = np.ones(image_shape, dtype=np.float64)

        if multiplier.shape != tuple(image_shape):
            raise ValueError(
                f'ROI shape {multiplier.shape} does not match frame image shape '
                f'{tuple(image_shape)} for channel {channel}.'
            )
        return multiplier

    @staticmethod
    def _finite_values(image):
        values = np.asarray(image, dtype=np.float64)
        return values[np.isfinite(values)]

    def _iter_frame_images(self, channel):
        '''Yield one foreground/background frame pair without expanding the PKL.'''

        sparse_data = self.pkl_data.get(f'frame_data_{channel}')
        if sparse_data is not None:
            if sparse_data.get('format') != 'sparse_frame_images_v1':
                raise ValueError(f'Unsupported frame_data_{channel} format.')
            shape = tuple(int(value) for value in sparse_data['shape'])
            if len(shape) != 3:
                raise ValueError(
                    f'frame_data_{channel} shape must contain three dimensions.'
                )
            offsets = np.asarray(sparse_data['frame_offsets'], dtype=np.int64)
            lines = np.asarray(sparse_data['line'], dtype=np.int64)
            pixels = np.asarray(sparse_data['pixel'], dtype=np.int64)
            foreground_weights = np.asarray(
                sparse_data['foreground'], dtype=np.float32
            )
            background_weights = np.asarray(
                sparse_data['background'], dtype=np.float32
            )
            event_count = lines.size
            if offsets.shape != (shape[0] + 1,) or offsets[0] != 0:
                raise ValueError(f'frame_data_{channel} has invalid frame offsets.')
            if offsets[-1] != event_count or not (
                    pixels.size == foreground_weights.size ==
                    background_weights.size == event_count):
                raise ValueError(f'frame_data_{channel} arrays have different lengths.')

            for frame_index in range(shape[0]):
                start = offsets[frame_index]
                stop = offsets[frame_index + 1]
                foreground = np.zeros(shape[1:], dtype=np.float32)
                background = np.zeros(shape[1:], dtype=np.float32)
                np.add.at(
                    foreground,
                    (lines[start:stop], pixels[start:stop]),
                    foreground_weights[start:stop],
                )
                np.add.at(
                    background,
                    (lines[start:stop], pixels[start:stop]),
                    background_weights[start:stop],
                )
                yield foreground, background
            return

        foreground_frames = self.pkl_data.get(f'frame_intensity_{channel}')
        background_frames = self.pkl_data.get(f'frame_bgrnd_{channel}')
        if foreground_frames is None or background_frames is None:
            return
        foreground_frames = np.asarray(foreground_frames, dtype=np.float32)
        background_frames = np.asarray(background_frames, dtype=np.float32)
        if foreground_frames.ndim != 3:
            raise ValueError(
                f'frame_intensity_{channel} must have shape (frames, rows, columns).'
            )
        if background_frames.shape != foreground_frames.shape:
            raise ValueError(
                f'frame_bgrnd_{channel} must match frame_intensity_{channel}.'
            )
        for frame_index in range(foreground_frames.shape[0]):
            yield foreground_frames[frame_index], background_frames[frame_index]

    def _frame_image_shape(self, channel):
        sparse_data = self.pkl_data.get(f'frame_data_{channel}')
        if sparse_data is not None:
            return tuple(int(value) for value in sparse_data['shape'][1:])
        foreground_frames = self.pkl_data.get(f'frame_intensity_{channel}')
        if foreground_frames is None:
            return None
        return np.asarray(foreground_frames).shape[1:]

    def _calculate_frame_results(self):
        '''Calculate export-only foreground and background results per frame.'''

        self.frame_results_by_channel = {}
        self.frame_results_file = self.anal_file
        if not isinstance(self.pkl_data, dict):
            return

        use_sem = bool(dpg.get_value('Error_type_checkbox'))
        for channel in ('1', '2'):
            image_shape = self._frame_image_shape(channel)
            if image_shape is None:
                continue

            roi_multiplier = self._frame_roi_multiplier(
                channel,
                image_shape,
            )
            brightness = dpg.get_value(f'Brightness_input_ch_{channel}')
            brightness_err = dpg.get_value(f'Brightness_err_input_ch_{channel}')
            omega = dpg.get_value(f'omega_input_ch_{channel}')
            effective_volume = 1e-15 * dpg.get_value(f'focal_vol_input_ch_{channel}')
            effective_volume_err = 1e-15 * dpg.get_value(f'focal_vol_err_input_ch_{channel}')
            effective_count = self._effective_pixel_count(
                roi_multiplier,
                self.PTU_Px_size,
                omega,
            )
            channel_results = []

            for foreground_frame, background_frame in self._iter_frame_images(channel):
                foreground = foreground_frame * roi_multiplier
                background = background_frame * roi_multiplier
                foreground_values = self._finite_values(foreground)
                if foreground_values.size == 0:
                    channel_results.append({})
                    continue

                mean_counts, counts_sem = self._mean_and_effective_sem(
                    foreground,
                    effective_count,
                )
                molecules, molecules_err = self.calc_molecules(
                    foreground,
                    self.PTU_Px_dwell,
                    1,
                    brightness,
                    brightness_err,
                )
                concentration, concentration_err = self.CONC(
                    molecules,
                    effective_volume,
                    molecules_err,
                    effective_volume_err,
                )
                concentration = 1e9 * concentration
                concentration_err = 1e9 * concentration_err

                molecule_values = self._finite_values(molecules)
                concentration_values = self._finite_values(concentration)
                mean_molecules = float(np.mean(molecule_values))
                mean_concentration = float(np.mean(concentration_values))
                molecules_error = self._reported_mean_error(
                    molecules,
                    molecules_err,
                    effective_count,
                    use_sem,
                )
                concentration_error = self._reported_mean_error(
                    concentration,
                    concentration_err,
                    effective_count,
                    use_sem,
                )

                mean_background, background_sem = self._mean_and_effective_sem(
                    background,
                    effective_count,
                )
                channel_results.append({
                    '<Counts>': mean_counts,
                    'Counts_std': counts_sem,
                    '<N_p>': mean_molecules,
                    'N_p_err': molecules_error,
                    '<C>': mean_concentration,
                    'C_err': concentration_error,
                    'C_median': float(np.median(concentration_values)),
                    'C_median_abs_err': float(
                        median_abs_deviation(concentration_values)
                    ),
                    '<Background counts>': mean_background,
                    'Background_counts_std': background_sem,
                    'N_effective_pixels': effective_count,
                })

            self.frame_results_by_channel[channel] = channel_results

    def _attach_frame_results(self, dataframe):
        '''Append dynamic frame columns to result rows before file export.'''

        self._calculate_frame_results()
        dataframe = dataframe.copy()
        for row_index, row in dataframe.iterrows():
            channel = str(int(row['Channel']))
            dataframe.at[
                row_index,
                'N_effective_pixels',
            ] = getattr(self, f'effective_pixels_ch_{channel}', np.nan)
            for frame_index, frame_result in enumerate(
                    self.frame_results_by_channel.get(channel, []), start=1):
                for metric, value in frame_result.items():
                    dataframe.at[
                        row_index,
                        f'Frame_{frame_index}_{metric}',
                    ] = value
        return dataframe

    def _background_image_for_roi(self, channel):
        """Apply the foreground ROI to a channel's background image."""
        self._ensure_display_subprocessors()
        foreground_processor = getattr(self, f'processor_{channel}')
        background_image = np.asarray(foreground_processor.background.image)

        if dpg.get_value('Auto_ROI_checkbox') and foreground_processor.all_masks:
            foreground_mask = foreground_processor.all_masks[0]
            roi_multiplier = np.where(foreground_mask == 0, np.nan, 1.0)
            return background_image * roi_multiplier

        if dpg.get_value('FILE_ROI_checkbox') and foreground_processor.roi_image is not None:
            return background_image * foreground_processor.roi_image

        return background_image

    @staticmethod
    def _set_non_photon_result_widgets(channel, value):
        dpg.set_value(f'sinle_mols_output_ch_{channel}', value)
        dpg.set_value(f'sinle_mols_err_output_ch_{channel}', value)
        dpg.set_value(f'single_conc_output_ch_{channel}', value)
        dpg.set_value(f'single_conc_err_output_ch_{channel}', value)

    def _update_background_histogram(self, channel, image, mean_value):
        """Display the background photons-per-pixel distribution for one channel."""
        finite_values = np.asarray(image, dtype=np.float64)
        finite_values = finite_values[np.isfinite(finite_values)]
        if finite_values.size == 0:
            return

        histogram, bin_edges = np.histogram(finite_values, density=True, bins='auto')
        bin_positions = bin_edges[:-1]
        populated_bins = histogram > 0
        histogram = histogram[populated_bins]
        bin_positions = bin_positions[populated_bins]
        if histogram.size == 0:
            return

        histogram_maximum = float(np.max(histogram))
        median_value = float(np.median(finite_values))
        dpg.set_value(f'phot_dist_ser_ch_{channel}', (bin_positions, histogram))
        dpg.set_value(
            f'phot_mean_ser_ch_{channel}',
            (np.array([mean_value]), np.array([histogram_maximum])),
        )
        dpg.set_value(
            f'phot_med_ser_ch_{channel}',
            (np.array([median_value]), np.array([histogram_maximum])),
        )
        dpg.set_axis_limits(
            f'hist_xphot_axis_ch{channel}',
            float(bin_edges[0]),
            float(bin_edges[-1]),
        )
        dpg.set_axis_limits(f'hist_yphot_axis_ch{channel}', 0, histogram_maximum)
        dpg.configure_item(
            f'phot_mean_ser_ch_{channel}',
            label='Mean = ' + str(np.round(mean_value, 1)),
        )
        dpg.configure_item(
            f'phot_med_ser_ch_{channel}',
            label='Median = ' + str(np.round(median_value, 1)),
        )
        dpg.set_value(f'tab_bar_h{channel}', f'tab_bar_phot_h{channel}')
        dpg.show_item(f'hist_phot_plot_ch{channel}')

    def _calculate_background_photons(self):
        """Calculate background photons per pixel without molecule conversion."""
        self.hide_histograms()
        for channel in ('1', '2'):
            if channel not in self.Channels:
                dpg.set_value(f'sinle_phot_output_ch_{channel}', 0.0)
                dpg.set_value(f'sinle_phot_err_output_ch_{channel}', 0.0)
                self._set_non_photon_result_widgets(channel, 0.0)
                continue

            background_roi = self._background_image_for_roi(channel)
            effective_count = self._effective_pixel_count(
                background_roi,
                self.PTU_Px_size,
                dpg.get_value(f'omega_input_ch_{channel}'),
            )
            mean_value, standard_error = self._mean_and_effective_sem(
                background_roi,
                effective_count,
            )
            setattr(self, f'mean_Background_Photons_ch_{channel}', mean_value)
            setattr(self, f'mean_Background_Photons_err_ch_{channel}', standard_error)
            setattr(self, f'effective_pixels_ch_{channel}', effective_count)
            setattr(self, f'image_{channel}_times_roi', background_roi)
            dpg.set_value(f'sinle_phot_output_ch_{channel}', mean_value)
            dpg.set_value(f'sinle_phot_err_output_ch_{channel}', standard_error)
            self._set_non_photon_result_widgets(channel, 0.0)
            self._update_background_histogram(channel, background_roi, mean_value)

    def _clear_decay_time_results(self):
        """Clear photon, molecule and concentration outputs for decay-time display."""
        self.hide_histograms()
        for channel in ('1', '2'):
            dpg.set_value(f'sinle_phot_output_ch_{channel}', 0.0)
            dpg.set_value(f'sinle_phot_err_output_ch_{channel}', 0.0)
            self._set_non_photon_result_widgets(channel, 0.0)

    def _reset_loaded_file_results(self):
        """Prevent measurements from a previously loaded file from being exported."""
        metric_names = (
            'mean_Photons',
            'mean_Photons_err',
            'mean_Molecules',
            'mean_Molecules_err',
            'mean_Concentration',
            'mean_Concentration_err',
            'median_C',
            'median_err_C',
            'mean_Background_Photons',
            'mean_Background_Photons_err',
        )
        for channel in ('1', '2'):
            for metric_name in metric_names:
                setattr(self, f'{metric_name}_ch_{channel}', None)
        self.frame_results_by_channel = {}
        self.frame_results_file = None

    def _export_current_auto_rois(self):
        """Save the current automatic ROI masks for all loaded channels."""
        if not dpg.get_value('Auto_ROI_checkbox'):
            return
        for channel_name in self.Channels:
            channel = '1' if '1' in channel_name else '2'
            processor = getattr(self, f'processor_{channel}')
            if processor.all_masks:
                roi_array = np.asarray(processor.all_masks[0], dtype=np.uint8)
                self.export_auto_roi(channel_name, roi_array)

    def callback_calculate(self, sender, app_data):
        if self.display_option == 'Background intensity':
            self._calculate_background_photons()
            return
        if self.display_option == 'Foreground decay times':
            self._export_current_auto_rois()
            self._clear_decay_time_results()
            return

        cmap = 'afmhot'
        rect = 0.1, 0.1, 0.85, 0.9
        norm = None
        if len(self.Channels) == 1:
            if '1' in self.Channels[0]:
                brightness_ch_1 = dpg.get_value('Brightness_input_ch_1')
                brightness_err_ch_1 = dpg.get_value('Brightness_err_input_ch_1')
                Veff_ch_1 = 1e-15 * dpg.get_value('focal_vol_input_ch_1')
                Veff_err_ch_1 = 1e-15 * dpg.get_value('focal_vol_err_input_ch_1')
                if self.processor_1.all_masks is not None and dpg.get_value('Auto_ROI_checkbox'):
                    ROI = self.processor_1.all_masks[0].astype(np.uint8)
                    self.export_auto_roi(self.Channels[0],ROI)
                    roi = np.where(ROI == 0, np.nan, 1)
                    img = self.processor_1.image
                    self.DF = img * roi
                else:
                    self.DF = self.image_1_times_roi
                Photons_1 = pd.DataFrame(self.DF)
                self.effective_pixels_ch_1 = self._effective_pixel_count(
                    self.DF,
                    self.PTU_Px_size,
                    dpg.get_value('omega_input_ch_1'),
                )
                sem_only = bool(dpg.get_value('Error_type_checkbox'))
                Molecules_ch_1 = self.calc_molecules(self.DF,
                                                     self.PTU_Px_dwell,
                                                     self.PTU_N_frames,
                                                     brightness_ch_1,
                                                     brightness_err_ch_1)[0]
                Molecules_err_ch_1 = self.calc_molecules(self.DF,
                                                         self.PTU_Px_dwell,
                                                         self.PTU_N_frames,
                                                         brightness_ch_1,
                                                         brightness_err_ch_1)[1]
                Concentration_ch_1 = 1e9 * self.CONC(Molecules_ch_1, Veff_ch_1, Molecules_err_ch_1, Veff_err_ch_1)[0]
                Concentration_err_ch_1 = 1e9 * self.CONC(Molecules_ch_1, Veff_ch_1, Molecules_err_ch_1, Veff_err_ch_1)[
                    1]
                self.mean_Photons_ch_1 = pd.DataFrame(Photons_1).stack().reset_index(drop=True).dropna().mean()
                self.mean_Photons_err_ch_1 = self._reported_mean_error(
                    Photons_1, None, self.effective_pixels_ch_1, sem_only
                )
                self.mean_Molecules_ch_1 = pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().mean()
                self.mean_Molecules_err_ch_1 = self._reported_mean_error(
                    Molecules_ch_1,
                    Molecules_err_ch_1,
                    self.effective_pixels_ch_1,
                    sem_only,
                )

                self.mean_Concentration_ch_1 = pd.DataFrame(Concentration_ch_1).stack().reset_index(
                    drop=True).dropna().mean()
                self.mean_Concentration_err_ch_1 = self._reported_mean_error(
                    Concentration_ch_1,
                    Concentration_err_ch_1,
                    self.effective_pixels_ch_1,
                    sem_only,
                )
                self.median_C_ch_1 = pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna().median()
                self.median_err_C_ch_1 = median_abs_deviation(
                    pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna())
                dpg.set_value('sinle_phot_output_ch_1', float(self.mean_Photons_ch_1))
                dpg.set_value('sinle_phot_err_output_ch_1', float(self.mean_Photons_err_ch_1))
                dpg.set_value('sinle_mols_output_ch_1', float(self.mean_Molecules_ch_1))
                dpg.set_value('sinle_mols_err_output_ch_1', float(self.mean_Molecules_err_ch_1))
                dpg.set_value('single_conc_output_ch_1', float(self.mean_Concentration_ch_1))
                dpg.set_value('single_conc_err_output_ch_1', float(self.mean_Concentration_err_ch_1))
                Molecules_ch_1 = pd.DataFrame(Molecules_ch_1)
                Concentration_ch_1 = pd.DataFrame(Concentration_ch_1)
                Molecules_err_ch_1 = pd.DataFrame(Molecules_err_ch_1)
                Concentration_err_ch_1 = pd.DataFrame(Concentration_err_ch_1)
                Phot_hist_ch_1, Phot_bins_ch_1 = np.histogram(Photons_1.stack().reset_index(drop=True).dropna().values,
                                                              density=True, bins='auto')
                Phot_bins_ch_1 = Phot_bins_ch_1[:-1]
                median_Photons_ch_1 = pd.DataFrame(Photons_1).stack().reset_index(drop=True).dropna().median()
                Mols_hist_ch_1, Mols_bins_ch_1 = np.histogram(
                    pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().values
                    , density=True, bins='auto')
                Mols_bins_ch_1 = Mols_bins_ch_1[:-1]
                median_Molecules_ch_1 = pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().median()
                Conc_hist_ch_1, Conc_bins_ch_1 = np.histogram(
                    pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna().values
                    , density=True, bins='auto')
                Conc_bins_ch_1 = Conc_bins_ch_1[:-1]
                ind = np.where(Conc_hist_ch_1 != 0)[0]
                Conc_hist_ch_1 = Conc_hist_ch_1[ind]
                Conc_bins_ch_1 = Conc_bins_ch_1[ind]
                ind = np.where(Mols_hist_ch_1 != 0)[0]
                Mols_hist_ch_1 = Mols_hist_ch_1[ind]
                Mols_bins_ch_1 = Mols_bins_ch_1[ind]
                ind = np.where(Phot_hist_ch_1 != 0)[0]
                Phot_hist_ch_1 = Phot_hist_ch_1[ind]
                Phot_bins_ch_1 = Phot_bins_ch_1[ind]
                dpg.set_value('c_dist_ser_ch_1', (Conc_bins_ch_1, Conc_hist_ch_1))
                dpg.set_value('c_mean_ser_ch_1',
                              (np.array([self.mean_Concentration_ch_1]), np.array([max(Conc_hist_ch_1)])))
                dpg.set_value('c_med_ser_ch_1', (np.array([self.median_C_ch_1]), np.array([max(Conc_hist_ch_1)])))
                dpg.set_axis_limits('hist_xc_axis_ch1', min(Conc_bins_ch_1), max(Conc_bins_ch_1))
                dpg.set_axis_limits('hist_yc_axis_ch1', 0, max(Conc_hist_ch_1))
                dpg.set_value('np_dist_ser_ch_1', (Mols_bins_ch_1, Mols_hist_ch_1))
                dpg.set_value('np_mean_ser_ch_1',
                              (np.array([self.mean_Molecules_ch_1]), np.array([max(Mols_hist_ch_1)])))
                dpg.set_value('np_med_ser_ch_1', (np.array([median_Molecules_ch_1]), np.array([max(Mols_hist_ch_1)])))
                dpg.set_axis_limits('hist_xnp_axis_ch1', min(Mols_bins_ch_1), max(Mols_bins_ch_1))
                dpg.set_axis_limits('hist_ynp_axis_ch1', 0, max(Mols_hist_ch_1))
                dpg.set_value('phot_dist_ser_ch_1', (Phot_bins_ch_1, Phot_hist_ch_1))
                dpg.set_value('phot_mean_ser_ch_1',
                              (np.array([self.mean_Photons_ch_1]), np.array([max(Phot_hist_ch_1)])))
                dpg.set_value('phot_med_ser_ch_1', (np.array([median_Photons_ch_1]), np.array([max(Phot_hist_ch_1)])))
                dpg.set_axis_limits('hist_xphot_axis_ch1', min(Phot_bins_ch_1), max(Phot_bins_ch_1))
                dpg.set_axis_limits('hist_yphot_axis_ch1', 0, max(Phot_hist_ch_1))
                dpg.configure_item('c_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Concentration_ch_1, 4)))
                dpg.configure_item('c_med_ser_ch_1', label='Median = ' + str(np.round(self.median_C_ch_1, 4)))
                dpg.configure_item('np_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Molecules_ch_1, 2)))
                dpg.configure_item('np_med_ser_ch_1', label='Median = ' + str(np.round(median_Molecules_ch_1, 2)))
                dpg.configure_item('phot_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Photons_ch_1, 1)))
                dpg.configure_item('phot_med_ser_ch_1', label='Median = ' + str(np.round(median_Photons_ch_1, 1)))
                try:
                    dpg.show_item('hist_conc_plot_ch1')
                except:
                    pass

                try:
                    dpg.show_item('hist_np_plot_ch1')
                except:
                    pass

                try:
                    dpg.show_item('hist_phot_plot_ch1')
                except:
                    pass

                if dpg.get_value('Photons_array_checkbox'):
                    phot_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_ch_1.csv')
                    Photons_1.to_csv(phot_array_path_ch_1, index=False, sep=',', header=None)
                else:
                    pass

                if dpg.get_value('Np_array_checkbox'):
                    Np_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_ch_1.csv')
                    Molecules_ch_1.to_csv(Np_array_path_ch_1, index=False, sep=',', header=None)
                    Np_err_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_err_ch_1.csv')
                    Molecules_err_ch_1.to_csv(Np_err_array_path_ch_1, index=False, sep=',', header=None)

                else:
                    pass
                if dpg.get_value('C_array_checkbox'):
                    Conc_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_ch_1.csv')
                    Concentration_ch_1.to_csv(Conc_array_path_ch_1, index=False, sep=',', header=None)
                    Conc_err_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_err_ch_1.csv')
                    Concentration_err_ch_1.to_csv(Conc_err_array_path_ch_1, index=False, sep=',', header=None)

                else:
                    pass

                if dpg.get_value('Photons_Hmaps_checkbox'):
                    phot_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_HM_ch_1.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Photons_1.min().min(), vmax=Photons_1.max().max())
                    ax.imshow(Photons_1, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(phot_hmap_path_ch_1)

                else:
                    pass

                if dpg.get_value('Np_Hmaps_checkbox'):
                    Np_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_HM_ch_1.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Molecules_ch_1.min().min(), vmax=Molecules_ch_1.max().max())
                    ax.imshow(Molecules_ch_1, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(Np_hmap_path_ch_1)

                else:
                    pass

                if dpg.get_value('C_Hmaps_checkbox'):
                    C_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_HM_ch_1.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Concentration_ch_1.min().min(),
                                                vmax=Concentration_ch_1.max().max())
                    ax.imshow(Concentration_ch_1, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(C_hmap_path_ch_1)

                else:
                    pass

            elif '2' in self.Channels[0]:
                brightness_ch_2 = dpg.get_value('Brightness_input_ch_2')
                brightness_err_ch_2 = dpg.get_value('Brightness_err_input_ch_2')
                Veff_ch_2 = 1e-15 * dpg.get_value('focal_vol_input_ch_2')
                Veff_err_ch_2 = 1e-15 * dpg.get_value('focal_vol_err_input_ch_2')
                if self.processor_2.all_masks is not None and dpg.get_value('Auto_ROI_checkbox'):
                    ROI = self.processor_2.all_masks[0].astype(np.uint8)
                    self.export_auto_roi(self.Channels[0],ROI)
                    roi = np.where(ROI == 0, np.nan, 1)
                    img = self.processor_2.image
                    self.DF2 = img * roi

                else:
                    self.DF2 = self.image_2_times_roi

                Photons_2 = pd.DataFrame(self.DF2)
                self.effective_pixels_ch_2 = self._effective_pixel_count(
                    self.DF2,
                    self.PTU_Px_size,
                    dpg.get_value('omega_input_ch_2'),
                )
                sem_only = bool(dpg.get_value('Error_type_checkbox'))
                self.mean_Photons_ch_2 = pd.DataFrame(Photons_2).stack().reset_index(drop=True).dropna().mean()
                self.mean_Photons_err_ch_2 = self._reported_mean_error(
                    Photons_2, None, self.effective_pixels_ch_2, sem_only
                )
                Molecules_ch_2 = self.calc_molecules(self.DF2,
                                                     self.PTU_Px_dwell,
                                                     self.PTU_N_frames,
                                                     brightness_ch_2,
                                                     brightness_err_ch_2)[0]
                Molecules_err_ch_2 = self.calc_molecules(self.DF2,
                                                         self.PTU_Px_dwell,
                                                         self.PTU_N_frames,
                                                         brightness_ch_2,
                                                         brightness_err_ch_2)[1]

                Concentration_ch_2 = 1e9 * self.CONC(Molecules_ch_2, Veff_ch_2, Molecules_err_ch_2, Veff_err_ch_2)[0]
                Concentration_err_ch_2 = 1e9 * self.CONC(Molecules_ch_2, Veff_ch_2, Molecules_err_ch_2, Veff_err_ch_2)[
                    1]
                self.mean_Molecules_ch_2 = pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().mean()
                self.mean_Molecules_err_ch_2 = self._reported_mean_error(
                    Molecules_ch_2,
                    Molecules_err_ch_2,
                    self.effective_pixels_ch_2,
                    sem_only,
                )

                self.mean_Concentration_ch_2 = pd.DataFrame(Concentration_ch_2).stack().reset_index(
                    drop=True).dropna().mean()
                self.mean_Concentration_err_ch_2 = self._reported_mean_error(
                    Concentration_ch_2,
                    Concentration_err_ch_2,
                    self.effective_pixels_ch_2,
                    sem_only,
                )

                self.median_C_ch_2 = pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna().median()
                self.median_err_C_ch_2 = median_abs_deviation(
                    pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna())
                dpg.set_value('sinle_phot_output_ch_2', float(self.mean_Photons_ch_2))
                dpg.set_value('sinle_phot_err_output_ch_2', float(self.mean_Photons_err_ch_2))
                dpg.set_value('sinle_mols_output_ch_2', float(self.mean_Molecules_ch_2))
                dpg.set_value('sinle_mols_err_output_ch_2', float(self.mean_Molecules_err_ch_2))
                dpg.set_value('single_conc_output_ch_2', float(self.mean_Concentration_ch_2))
                dpg.set_value('single_conc_err_output_ch_2', float(self.mean_Concentration_err_ch_2))
                Molecules_ch_2 = pd.DataFrame(Molecules_ch_2)
                Concentration_ch_2 = pd.DataFrame(Concentration_ch_2)
                Molecules_err_ch_2 = pd.DataFrame(Molecules_err_ch_2)
                Concentration_err_ch_2 = pd.DataFrame(Concentration_err_ch_2)
                Phot_hist_ch_2, Phot_bins_ch_2 = np.histogram(Photons_2.stack().reset_index(drop=True).dropna().values,
                                                              density=True, bins='auto')
                Phot_bins_ch_2 = Phot_bins_ch_2[:-1]
                median_Photons_ch_2 = pd.DataFrame(Photons_2).stack().reset_index(drop=True).dropna().median()
                Mols_hist_ch_2, Mols_bins_ch_2 = np.histogram(
                    pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().values
                    , density=True, bins='auto')
                Mols_bins_ch_2 = Mols_bins_ch_2[:-1]
                median_Molecules_ch_2 = pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().median()
                Conc_hist_ch_2, Conc_bins_ch_2 = np.histogram(
                    pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna().values
                    , density=True, bins='auto')
                Conc_bins_ch_2 = Conc_bins_ch_2[:-1]
                ind = np.where(Conc_hist_ch_2 != 0)[0]
                Conc_hist_ch_2 = Conc_hist_ch_2[ind]
                Conc_bins_ch_2 = Conc_bins_ch_2[ind]
                ind = np.where(Mols_hist_ch_2 != 0)[0]
                Mols_hist_ch_2 = Mols_hist_ch_2[ind]
                Mols_bins_ch_2 = Mols_bins_ch_2[ind]
                ind = np.where(Phot_hist_ch_2 != 0)[0]
                Phot_hist_ch_2 = Phot_hist_ch_2[ind]
                Phot_bins_ch_2 = Phot_bins_ch_2[ind]
                dpg.set_value('c_dist_ser_ch_2', (Conc_bins_ch_2, Conc_hist_ch_2))
                dpg.set_value('c_mean_ser_ch_2',
                              (np.array([self.mean_Concentration_ch_2]), np.array([max(Conc_hist_ch_2)])))
                dpg.set_value('c_med_ser_ch_2', (np.array([self.median_C_ch_2]), np.array([max(Conc_hist_ch_2)])))
                dpg.set_axis_limits('hist_xc_axis_ch2', min(Conc_bins_ch_2), max(Conc_bins_ch_2))
                dpg.set_axis_limits('hist_yc_axis_ch2', 0, max(Conc_hist_ch_2))
                dpg.set_value('np_dist_ser_ch_2', (Mols_bins_ch_2, Mols_hist_ch_2))
                dpg.set_value('np_mean_ser_ch_2',
                              (np.array([self.mean_Molecules_ch_2]), np.array([max(Mols_hist_ch_2)])))
                dpg.set_value('np_med_ser_ch_2', (np.array([median_Molecules_ch_2]), np.array([max(Mols_hist_ch_2)])))
                dpg.set_axis_limits('hist_xnp_axis_ch2', min(Mols_bins_ch_2), max(Mols_bins_ch_2))
                dpg.set_axis_limits('hist_ynp_axis_ch2', 0, max(Mols_hist_ch_2))
                dpg.set_value('phot_dist_ser_ch_2', (Phot_bins_ch_2, Phot_hist_ch_2))
                dpg.set_value('phot_mean_ser_ch_2',
                              (np.array([self.mean_Photons_ch_2]), np.array([max(Phot_hist_ch_2)])))
                dpg.set_value('phot_med_ser_ch_2', (np.array([median_Photons_ch_2]), np.array([max(Phot_hist_ch_2)])))
                dpg.set_axis_limits('hist_xphot_axis_ch2', min(Phot_bins_ch_2), max(Phot_bins_ch_2))
                dpg.set_axis_limits('hist_yphot_axis_ch2', 0, max(Phot_hist_ch_2))
                dpg.configure_item('c_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Concentration_ch_2, 4)))
                dpg.configure_item('c_med_ser_ch_2', label='Median = ' + str(np.round(self.median_C_ch_2, 4)))
                dpg.configure_item('np_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Molecules_ch_2, 2)))
                dpg.configure_item('np_med_ser_ch_2', label='Median = ' + str(np.round(median_Molecules_ch_2, 2)))
                dpg.configure_item('phot_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Photons_ch_2, 1)))
                dpg.configure_item('phot_med_ser_ch_2', label='Median = ' + str(np.round(median_Photons_ch_2, 1)))

                try:
                    dpg.show_item('hist_conc_plot_ch2')
                except:
                    pass

                try:
                    dpg.show_item('hist_np_plot_ch2')
                except:
                    pass

                try:
                    dpg.show_item('hist_phot_plot_ch2')
                except:
                    pass

                if dpg.get_value('Photons_array_checkbox'):
                    phot_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_ch_2.csv')
                    Photons_2.to_csv(phot_array_path_ch_2, index=False, sep=',', header=None)
                else:
                    pass

                if dpg.get_value('Np_array_checkbox'):
                    Np_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_ch_2.csv')
                    Molecules_ch_2.to_csv(Np_array_path_ch_2, index=False, sep=',', header=None)
                    Np_err_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_err_ch_2.csv')
                    Molecules_err_ch_2.to_csv(Np_err_array_path_ch_2, index=False, sep=',', header=None)
                else:
                    pass
                if dpg.get_value('C_array_checkbox'):
                    Conc_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_ch_2.csv')
                    Concentration_ch_2.to_csv(Conc_array_path_ch_2, index=False, sep=',', header=None)
                    Conc_err_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_err_ch_2.csv')
                    Concentration_err_ch_2.to_csv(Conc_err_array_path_ch_2, index=False, sep=',', header=None)

                else:
                    pass

                if dpg.get_value('Photons_Hmaps_checkbox'):
                    phot_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_HM_ch_2.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Photons_2.min().min(), vmax=Photons_2.max().max())
                    ax.imshow(Photons_2, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(phot_hmap_path_ch_2)

                else:
                    pass

                if dpg.get_value('Np_Hmaps_checkbox'):
                    Np_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_HM_ch_2.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Molecules_ch_2.min().min(), vmax=Molecules_ch_2.max().max())
                    ax.imshow(Molecules_ch_2, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(Np_hmap_path_ch_2)

                else:
                    pass

                if dpg.get_value('C_Hmaps_checkbox'):
                    C_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_HM_ch_2.png')
                    fig = Figure(facecolor='white')
                    ax = fig.add_axes(rect)
                    norm = mpl.colors.Normalize(vmin=Concentration_ch_2.min().min(),
                                                vmax=Concentration_ch_2.max().max())
                    ax.imshow(Concentration_ch_2, cmap=cmap)
                    ax.axis('off')
                    fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                    FigureCanvas(fig).print_png(C_hmap_path_ch_2)

                else:
                    pass
            else:
                pass


        elif len(self.Channels) == 2:
            brightness_ch_1 = dpg.get_value('Brightness_input_ch_1')
            brightness_err_ch_1 = dpg.get_value('Brightness_err_input_ch_1')
            Veff_ch_1 = 1e-15 * dpg.get_value('focal_vol_input_ch_1')
            Veff_err_ch_1 = 1e-15 * dpg.get_value('focal_vol_err_input_ch_1')
            if self.processor_1.all_masks is not None and dpg.get_value('Auto_ROI_checkbox'):
                ROI = self.processor_1.all_masks[0].astype(np.uint8)
                self.export_auto_roi(self.Channels[0],ROI)
                roi = np.where(ROI == 0, np.nan, 1)
                img = self.processor_1.image
                self.DF = img * roi
            else:
                self.DF = self.image_1_times_roi
            
            Photons_1 = pd.DataFrame(self.DF)
            self.effective_pixels_ch_1 = self._effective_pixel_count(
                self.DF,
                self.PTU_Px_size,
                dpg.get_value('omega_input_ch_1'),
            )
            sem_only = bool(dpg.get_value('Error_type_checkbox'))
            Molecules_ch_1 = self.calc_molecules(self.DF,
                                                 self.PTU_Px_dwell,
                                                 self.PTU_N_frames,
                                                 brightness_ch_1,
                                                 brightness_err_ch_1)[0]
            Molecules_err_ch_1 = self.calc_molecules(self.DF,
                                                     self.PTU_Px_dwell,
                                                     self.PTU_N_frames,
                                                     brightness_ch_1,
                                                     brightness_err_ch_1)[1]
            Concentration_ch_1 = 1e9 * self.CONC(Molecules_ch_1, Veff_ch_1, Molecules_err_ch_1, Veff_err_ch_1)[0]
            Concentration_err_ch_1 = 1e9 * self.CONC(Molecules_ch_1, Veff_ch_1, Molecules_err_ch_1, Veff_err_ch_1)[1]
            self.mean_Photons_ch_1 = pd.DataFrame(Photons_1).stack().reset_index(drop=True).dropna().mean()
            self.mean_Photons_err_ch_1 = self._reported_mean_error(
                Photons_1, None, self.effective_pixels_ch_1, sem_only
            )
            self.mean_Molecules_ch_1 = pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().mean()
            self.mean_Molecules_err_ch_1 = self._reported_mean_error(
                Molecules_ch_1,
                Molecules_err_ch_1,
                self.effective_pixels_ch_1,
                sem_only,
            )

            self.mean_Concentration_ch_1 = pd.DataFrame(Concentration_ch_1).stack().reset_index(
                drop=True).dropna().mean()
            self.mean_Concentration_err_ch_1 = self._reported_mean_error(
                Concentration_ch_1,
                Concentration_err_ch_1,
                self.effective_pixels_ch_1,
                sem_only,
            )

            self.median_C_ch_1 = pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna().median()
            self.median_err_C_ch_1 = median_abs_deviation(
                pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna())
            dpg.set_value('sinle_phot_output_ch_1', float(self.mean_Photons_ch_1))
            dpg.set_value('sinle_phot_err_output_ch_1', float(self.mean_Photons_err_ch_1))
            dpg.set_value('sinle_mols_output_ch_1', float(self.mean_Molecules_ch_1))
            dpg.set_value('sinle_mols_err_output_ch_1', float(self.mean_Molecules_err_ch_1))
            dpg.set_value('single_conc_output_ch_1', float(self.mean_Concentration_ch_1))
            dpg.set_value('single_conc_err_output_ch_1', float(self.mean_Concentration_err_ch_1))
            Molecules_ch_1 = pd.DataFrame(Molecules_ch_1)
            Concentration_ch_1 = pd.DataFrame(Concentration_ch_1)
            Molecules_err_ch_1 = pd.DataFrame(Molecules_err_ch_1)
            Concentration_err_ch_1 = pd.DataFrame(Concentration_err_ch_1)
            Phot_hist_ch_1, Phot_bins_ch_1 = np.histogram(Photons_1.stack().reset_index(drop=True).dropna().values,
                                                          density=True, bins='auto')
            Phot_bins_ch_1 = Phot_bins_ch_1[:-1]
            median_Photons_ch_1 = pd.DataFrame(Photons_1).stack().reset_index(drop=True).dropna().median()
            Mols_hist_ch_1, Mols_bins_ch_1 = np.histogram(
                pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().values
                , density=True, bins='auto')
            Mols_bins_ch_1 = Mols_bins_ch_1[:-1]
            median_Molecules_ch_1 = pd.DataFrame(Molecules_ch_1).stack().reset_index(drop=True).dropna().median()
            Conc_hist_ch_1, Conc_bins_ch_1 = np.histogram(
                pd.DataFrame(Concentration_ch_1).stack().reset_index(drop=True).dropna().values
                , density=True, bins='auto')
            Conc_bins_ch_1 = Conc_bins_ch_1[:-1]
            ind = np.where(Conc_hist_ch_1 != 0)[0]
            Conc_hist_ch_1 = Conc_hist_ch_1[ind]
            Conc_bins_ch_1 = Conc_bins_ch_1[ind]
            ind = np.where(Mols_hist_ch_1 != 0)[0]
            Mols_hist_ch_1 = Mols_hist_ch_1[ind]
            Mols_bins_ch_1 = Mols_bins_ch_1[ind]
            ind = np.where(Phot_hist_ch_1 != 0)[0]
            Phot_hist_ch_1 = Phot_hist_ch_1[ind]
            Phot_bins_ch_1 = Phot_bins_ch_1[ind]
            dpg.set_value('c_dist_ser_ch_1', (Conc_bins_ch_1, Conc_hist_ch_1))
            dpg.set_value('c_mean_ser_ch_1',
                          (np.array([self.mean_Concentration_ch_1]), np.array([max(Conc_hist_ch_1)])))
            dpg.set_value('c_med_ser_ch_1', (np.array([self.median_C_ch_1]), np.array([max(Conc_hist_ch_1)])))
            dpg.set_axis_limits('hist_xc_axis_ch1', min(Conc_bins_ch_1), max(Conc_bins_ch_1))
            dpg.set_axis_limits('hist_yc_axis_ch1', 0, max(Conc_hist_ch_1))
            dpg.set_value('np_dist_ser_ch_1', (Mols_bins_ch_1, Mols_hist_ch_1))
            dpg.set_value('np_mean_ser_ch_1', (np.array([self.mean_Molecules_ch_1]), np.array([max(Mols_hist_ch_1)])))
            dpg.set_value('np_med_ser_ch_1', (np.array([median_Molecules_ch_1]), np.array([max(Mols_hist_ch_1)])))
            dpg.set_axis_limits('hist_xnp_axis_ch1', min(Mols_bins_ch_1), max(Mols_bins_ch_1))
            dpg.set_axis_limits('hist_ynp_axis_ch1', 0, max(Mols_hist_ch_1))
            dpg.set_value('phot_dist_ser_ch_1', (Phot_bins_ch_1, Phot_hist_ch_1))
            dpg.set_value('phot_mean_ser_ch_1', (np.array([self.mean_Photons_ch_1]), np.array([max(Phot_hist_ch_1)])))
            dpg.set_value('phot_med_ser_ch_1', (np.array([median_Photons_ch_1]), np.array([max(Phot_hist_ch_1)])))
            dpg.set_axis_limits('hist_xphot_axis_ch1', min(Phot_bins_ch_1), max(Phot_bins_ch_1))
            dpg.set_axis_limits('hist_yphot_axis_ch1', 0, max(Phot_hist_ch_1))
            dpg.configure_item('c_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Concentration_ch_1, 4)))
            dpg.configure_item('c_med_ser_ch_1', label='Median = ' + str(np.round(self.median_C_ch_1, 4)))
            dpg.configure_item('np_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Molecules_ch_1, 2)))
            dpg.configure_item('np_med_ser_ch_1', label='Median = ' + str(np.round(median_Molecules_ch_1, 2)))
            dpg.configure_item('phot_mean_ser_ch_1', label='Mean = ' + str(np.round(self.mean_Photons_ch_1, 1)))
            dpg.configure_item('phot_med_ser_ch_1', label='Median = ' + str(np.round(median_Photons_ch_1, 1)))

            try:
                dpg.show_item('hist_conc_plot_ch1')
            except:
                pass

            try:
                dpg.show_item('hist_np_plot_ch1')
            except:
                pass

            try:
                dpg.show_item('hist_phot_plot_ch1')
            except:
                pass

            if dpg.get_value('Photons_array_checkbox'):
                phot_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_ch_1.csv')
                Photons_1.to_csv(phot_array_path_ch_1, index=False, sep=',', header=None)
            else:
                pass

            if dpg.get_value('Np_array_checkbox'):
                Np_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_ch_1.csv')
                Molecules_ch_1.to_csv(Np_array_path_ch_1, index=False, sep=',', header=None)
                Np_err_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_err_ch_1.csv')
                Molecules_err_ch_1.to_csv(Np_err_array_path_ch_1, index=False, sep=',', header=None)

            else:
                pass
            if dpg.get_value('C_array_checkbox'):
                Conc_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_ch_1.csv')
                Concentration_ch_1.to_csv(Conc_array_path_ch_1, index=False, sep=',', header=None)
                Conc_err_array_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_err_ch_1.csv')
                Concentration_err_ch_1.to_csv(Conc_err_array_path_ch_1, index=False, sep=',', header=None)

            else:
                pass

            if dpg.get_value('Photons_Hmaps_checkbox'):
                phot_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_HM_ch_1.png')
                fig = Figure(facecolor='white')
                ax = fig.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Photons_1.min().min(), vmax=Photons_1.max().max())
                ax.imshow(Photons_1, cmap=cmap)
                ax.axis('off')
                fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig).print_png(phot_hmap_path_ch_1)

            else:
                pass

            if dpg.get_value('Np_Hmaps_checkbox'):
                Np_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_Np_HM_ch_1.png')
                fig1 = Figure(facecolor='white')
                ax = fig1.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Molecules_ch_1.min().min(), vmax=Molecules_ch_1.max().max())
                ax.imshow(Molecules_ch_1, cmap=cmap)
                ax.axis('off')
                fig1.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig1).print_png(Np_hmap_path_ch_1)

            else:
                pass

            if dpg.get_value('C_Hmaps_checkbox'):
                C_hmap_path_ch_1 = os.path.join(self.PTU_directory, self.anal_file + '_conc_HM_ch_1.png')
                fig1 = Figure(facecolor='white')
                ax = fig1.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Concentration_ch_1.min().min(), vmax=Concentration_ch_1.max().max())
                ax.imshow(Concentration_ch_1, cmap=cmap)
                ax.axis('off')
                fig1.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig1).print_png(C_hmap_path_ch_1)

            else:
                pass

            brightness_ch_2 = dpg.get_value('Brightness_input_ch_2')
            brightness_err_ch_2 = dpg.get_value('Brightness_err_input_ch_2')
            Veff_ch_2 = 1e-15 * dpg.get_value('focal_vol_input_ch_2')
            Veff_err_ch_2 = 1e-15 * dpg.get_value('focal_vol_err_input_ch_2')
            if self.processor_2.all_masks is not None and dpg.get_value('Auto_ROI_checkbox'):
                ROI = self.processor_2.all_masks[0].astype(np.uint8)
                self.export_auto_roi(self.Channels[1],ROI)
                roi = np.where(ROI == 0, np.nan, 1)
                img = self.processor_2.image
                self.DF2 = img * roi
            else:
                self.DF2 = self.image_2_times_roi
            
            Photons_2 = pd.DataFrame(self.DF2)
            self.effective_pixels_ch_2 = self._effective_pixel_count(
                self.DF2,
                self.PTU_Px_size,
                dpg.get_value('omega_input_ch_2'),
            )
            sem_only = bool(dpg.get_value('Error_type_checkbox'))
            self.mean_Photons_ch_2 = pd.DataFrame(Photons_2).stack().reset_index(drop=True).dropna().mean()
            self.mean_Photons_err_ch_2 = self._reported_mean_error(
                Photons_2, None, self.effective_pixels_ch_2, sem_only
            )
            Molecules_ch_2 = self.calc_molecules(self.DF2,
                                                 self.PTU_Px_dwell,
                                                 self.PTU_N_frames,
                                                 brightness_ch_2,
                                                 brightness_err_ch_2)[0]
            Molecules_err_ch_2 = self.calc_molecules(self.DF2,
                                                     self.PTU_Px_dwell,
                                                     self.PTU_N_frames,
                                                     brightness_ch_2,
                                                     brightness_err_ch_2)[1]

            Concentration_ch_2 = 1e9 * self.CONC(Molecules_ch_2, Veff_ch_2, Molecules_err_ch_2, Veff_err_ch_2)[0]
            Concentration_err_ch_2 = 1e9 * self.CONC(Molecules_ch_2, Veff_ch_2, Molecules_err_ch_2, Veff_err_ch_2)[1]
            self.mean_Molecules_ch_2 = pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().mean()
            self.mean_Molecules_err_ch_2 = self._reported_mean_error(
                Molecules_ch_2,
                Molecules_err_ch_2,
                self.effective_pixels_ch_2,
                sem_only,
            )
            self.mean_Concentration_ch_2 = pd.DataFrame(Concentration_ch_2).stack().reset_index(
                drop=True).dropna().mean()
            self.mean_Concentration_err_ch_2 = self._reported_mean_error(
                Concentration_ch_2,
                Concentration_err_ch_2,
                self.effective_pixels_ch_2,
                sem_only,
            )
            self.median_C_ch_2 = pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna().median()
            self.median_err_C_ch_2 = median_abs_deviation(
                pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna())
            dpg.set_value('sinle_phot_output_ch_2', float(self.mean_Photons_ch_2))
            dpg.set_value('sinle_phot_err_output_ch_2', float(self.mean_Photons_err_ch_2))
            dpg.set_value('sinle_mols_output_ch_2', float(self.mean_Molecules_ch_2))
            dpg.set_value('sinle_mols_err_output_ch_2', float(self.mean_Molecules_err_ch_2))
            dpg.set_value('single_conc_output_ch_2', float(self.mean_Concentration_ch_2))
            dpg.set_value('single_conc_err_output_ch_2', float(self.mean_Concentration_err_ch_2))
            Molecules_ch_2 = pd.DataFrame(Molecules_ch_2)
            Concentration_ch_2 = pd.DataFrame(Concentration_ch_2)
            Molecules_err_ch_2 = pd.DataFrame(Molecules_err_ch_2)
            Concentration_err_ch_2 = pd.DataFrame(Concentration_err_ch_2)
            Phot_hist_ch_2, Phot_bins_ch_2 = np.histogram(Photons_2.stack().reset_index(drop=True).dropna().values,
                                                          density=True, bins='auto')
            Phot_bins_ch_2 = Phot_bins_ch_2[:-1]
            median_Photons_ch_2 = pd.DataFrame(Photons_2).stack().reset_index(drop=True).dropna().median()
            Mols_hist_ch_2, Mols_bins_ch_2 = np.histogram(
                pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().values
                , density=True, bins='auto')
            Mols_bins_ch_2 = Mols_bins_ch_2[:-1]
            median_Molecules_ch_2 = pd.DataFrame(Molecules_ch_2).stack().reset_index(drop=True).dropna().median()
            Conc_hist_ch_2, Conc_bins_ch_2 = np.histogram(
                pd.DataFrame(Concentration_ch_2).stack().reset_index(drop=True).dropna().values
                , density=True, bins='auto')
            Conc_bins_ch_2 = Conc_bins_ch_2[:-1]
            ind = np.where(Conc_hist_ch_2 != 0)[0]
            Conc_hist_ch_2 = Conc_hist_ch_2[ind]
            Conc_bins_ch_2 = Conc_bins_ch_2[ind]
            ind = np.where(Mols_hist_ch_2 != 0)[0]
            Mols_hist_ch_2 = Mols_hist_ch_2[ind]
            Mols_bins_ch_2 = Mols_bins_ch_2[ind]
            ind = np.where(Phot_hist_ch_2 != 0)[0]
            Phot_hist_ch_2 = Phot_hist_ch_2[ind]
            Phot_bins_ch_2 = Phot_bins_ch_2[ind]
            dpg.set_value('c_dist_ser_ch_2', (Conc_bins_ch_2, Conc_hist_ch_2))
            dpg.set_value('c_mean_ser_ch_2',
                          (np.array([self.mean_Concentration_ch_2]), np.array([max(Conc_hist_ch_2)])))
            dpg.set_value('c_med_ser_ch_2', (np.array([self.median_C_ch_2]), np.array([max(Conc_hist_ch_2)])))
            dpg.set_axis_limits('hist_xc_axis_ch2', min(Conc_bins_ch_2), max(Conc_bins_ch_2))
            dpg.set_axis_limits('hist_yc_axis_ch2', 0, max(Conc_hist_ch_2))
            dpg.set_value('np_dist_ser_ch_2', (Mols_bins_ch_2, Mols_hist_ch_2))
            dpg.set_value('np_mean_ser_ch_2', (np.array([self.mean_Molecules_ch_2]), np.array([max(Mols_hist_ch_2)])))
            dpg.set_value('np_med_ser_ch_2', (np.array([median_Molecules_ch_2]), np.array([max(Mols_hist_ch_2)])))
            dpg.set_axis_limits('hist_xnp_axis_ch2', min(Mols_bins_ch_2), max(Mols_bins_ch_2))
            dpg.set_axis_limits('hist_ynp_axis_ch2', 0, max(Mols_hist_ch_2))
            dpg.set_value('phot_dist_ser_ch_2', (Phot_bins_ch_2, Phot_hist_ch_2))
            dpg.set_value('phot_mean_ser_ch_2', (np.array([self.mean_Photons_ch_2]), np.array([max(Phot_hist_ch_2)])))
            dpg.set_value('phot_med_ser_ch_2', (np.array([median_Photons_ch_2]), np.array([max(Phot_hist_ch_2)])))
            dpg.set_axis_limits('hist_xphot_axis_ch2', min(Phot_bins_ch_2), max(Phot_bins_ch_2))
            dpg.set_axis_limits('hist_yphot_axis_ch2', 0, max(Phot_hist_ch_2))
            dpg.configure_item('c_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Concentration_ch_2, 4)))
            dpg.configure_item('c_med_ser_ch_2', label='Median = ' + str(np.round(self.median_C_ch_2, 4)))
            dpg.configure_item('np_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Molecules_ch_2, 2)))
            dpg.configure_item('np_med_ser_ch_2', label='Median = ' + str(np.round(median_Molecules_ch_2, 2)))
            dpg.configure_item('phot_mean_ser_ch_2', label='Mean = ' + str(np.round(self.mean_Photons_ch_2, 1)))
            dpg.configure_item('phot_med_ser_ch_2', label='Median = ' + str(np.round(median_Photons_ch_2, 1)))

            try:
                dpg.show_item('hist_conc_plot_ch2')
            except:
                pass

            try:
                dpg.show_item('hist_np_plot_ch2')
            except:
                pass

            try:
                dpg.show_item('hist_phot_plot_ch2')
            except:
                pass

            if dpg.get_value('Photons_array_checkbox'):
                phot_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_ch_2.csv')
                Photons_2.to_csv(phot_array_path_ch_2, index=False, sep=',', header=None)
            else:
                pass

            if dpg.get_value('Np_array_checkbox'):
                Np_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_ch_2.csv')
                Molecules_ch_2.to_csv(Np_array_path_ch_2, index=False, sep=',', header=None)
                Np_err_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_err_ch_2.csv')
                Molecules_err_ch_2.to_csv(Np_err_array_path_ch_2, index=False, sep=',', header=None)
            else:
                pass
            if dpg.get_value('C_array_checkbox'):
                Conc_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_ch_2.csv')
                Concentration_ch_2.to_csv(Conc_array_path_ch_2, index=False, sep=',', header=None)
                Conc_err_array_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_err_ch_2.csv')
                Concentration_err_ch_2.to_csv(Conc_err_array_path_ch_2, index=False, sep=',', header=None)
            else:
                pass

            if dpg.get_value('Photons_Hmaps_checkbox'):
                phot_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Phot_HM_ch_2.png')
                fig = Figure(facecolor='white')
                ax = fig.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Photons_2.min().min(), vmax=Photons_2.max().max())
                ax.imshow(Photons_2, cmap=cmap)
                ax.axis('off')
                fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig).print_png(phot_hmap_path_ch_2)

            else:
                pass

            if dpg.get_value('Np_Hmaps_checkbox'):
                Np_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_Np_HM_ch_2.png')
                fig2 = Figure(facecolor='white')
                ax = fig2.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Molecules_ch_2.min().min(), vmax=Molecules_ch_2.max().max())
                ax.imshow(Molecules_ch_2, cmap=cmap)
                ax.axis('off')
                fig2.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig2).print_png(Np_hmap_path_ch_2)

            else:
                pass

            if dpg.get_value('C_Hmaps_checkbox'):
                C_hmap_path_ch_2 = os.path.join(self.PTU_directory, self.anal_file + '_conc_HM_ch_2.png')
                fig2 = Figure(facecolor='white')
                ax = fig2.add_axes(rect)
                norm = mpl.colors.Normalize(vmin=Concentration_ch_2.min().min(), vmax=Concentration_ch_2.max().max())
                ax.imshow(Concentration_ch_2, cmap=cmap)
                ax.axis('off')
                fig2.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=ax)
                FigureCanvas(fig2).print_png(C_hmap_path_ch_2)

            else:
                pass

        else:
            pass

    def callback_calculate_all(self, sender, app_data, user_data=None,
                               refresh_progress=False):
        self.initialize_res_df()
        # Timings cover all calculations and ROI variants performed for each
        # PTU in this Calculate all invocation.  They do not affect numerical
        # results and are consumed only by automation reports.
        self.last_batch_file_timings = []
        filenames = [f.replace('.ptu', '') for f in self.files]
        calibration = self._current_calibration_widget_values()
        if dpg.get_value('Auto_ROI_checkbox') or (
                not dpg.get_value('Auto_ROI_checkbox') and not dpg.get_value('FILE_ROI_checkbox')):
            roiname = dpg.get_value('ROI_name_tag')
            for cnt, an_file in enumerate(filenames):
                file_started = time.perf_counter()
                self.anal_file = an_file
                dpg.configure_item('file_box', default_value=an_file)
                if refresh_progress:
                    dpg.render_dearpygui_frame()
                self.callback_listbox('file_box', self.anal_file, calibration)
                if refresh_progress:
                    dpg.render_dearpygui_frame()
                if len(self.Channels) == 1:
                    if '1' in self.Channels[0]:

                        Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                             roiname,
                                                             1,
                                                             self.mean_Photons_ch_1,
                                                             self.mean_Photons_err_ch_1,
                                                             self.mean_Molecules_ch_1,
                                                             self.mean_Molecules_err_ch_1,
                                                             self.mean_Concentration_ch_1,
                                                             self.mean_Concentration_err_ch_1,
                                                             self.median_C_ch_1,
                                                             self.median_err_C_ch_1,
                                                             self.mean_Background_Photons_ch_1,
                                                             self.mean_Background_Photons_err_ch_1]],
                                                           columns=self._base_result_columns())

                    elif '2' in self.Channels[0]:
                        Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                             roiname,
                                                             2,
                                                             self.mean_Photons_ch_2,
                                                             self.mean_Photons_err_ch_2,
                                                             self.mean_Molecules_ch_2,
                                                             self.mean_Molecules_err_ch_2,
                                                             self.mean_Concentration_ch_2,
                                                             self.mean_Concentration_err_ch_2,
                                                             self.median_C_ch_2,
                                                             self.median_err_C_ch_2,
                                                             self.mean_Background_Photons_ch_2,
                                                             self.mean_Background_Photons_err_ch_2]],
                                                           columns=self._base_result_columns())
                    else:
                        pass

                if len(self.Channels) == 2:
                    Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                         roiname,
                                                         1,
                                                         self.mean_Photons_ch_1,
                                                         self.mean_Photons_err_ch_1,
                                                         self.mean_Molecules_ch_1,
                                                         self.mean_Molecules_err_ch_1,
                                                         self.mean_Concentration_ch_1,
                                                         self.mean_Concentration_err_ch_1,
                                                         self.median_C_ch_1,
                                                         self.median_err_C_ch_1,
                                                         self.mean_Background_Photons_ch_1,
                                                         self.mean_Background_Photons_err_ch_1],
                                                        [self.anal_file,
                                                         roiname,
                                                         2,
                                                         self.mean_Photons_ch_2,
                                                         self.mean_Photons_err_ch_2,
                                                         self.mean_Molecules_ch_2,
                                                         self.mean_Molecules_err_ch_2,
                                                         self.mean_Concentration_ch_2,
                                                         self.mean_Concentration_err_ch_2,
                                                         self.median_C_ch_2,
                                                         self.median_err_C_ch_2,
                                                         self.mean_Background_Photons_ch_2,
                                                         self.mean_Background_Photons_err_ch_2]],
                                                       columns=self._base_result_columns())
                Sing_Results_DF_tmp = self._attach_frame_results(
                    Sing_Results_DF_tmp
                )
                self.Sing_Results_DF = pd.concat([self.Sing_Results_DF, Sing_Results_DF_tmp]).reset_index(drop=True)
                self._pkl_file()
                ptu_path = os.path.join(self.PTU_directory, an_file + '.ptu')
                self.last_batch_file_timings.append({
                    'filename': an_file + '.ptu',
                    'size_bytes': os.path.getsize(ptu_path),
                    'wall_time_seconds': time.perf_counter() - file_started,
                })
        elif dpg.get_value('FILE_ROI_checkbox'):
            for cnt, an_file in enumerate(filenames):
                file_started = time.perf_counter()
                self.anal_file = an_file
                dpg.configure_item('file_box', default_value=an_file)
                if refresh_progress:
                    dpg.render_dearpygui_frame()
                self.callback_listbox('file_box', self.anal_file, calibration)
                ROIS = dpg.get_item_configuration('ROI_names_combo_tag')['items']
                if refresh_progress:
                    dpg.render_dearpygui_frame()
                for ROI in ROIS:
                    dpg.set_value('ROI_names_combo_tag', ROI)
                    self.callback_ROI_names_combo('ROI_names_combo_tag', ROI)
                    if refresh_progress:
                        dpg.render_dearpygui_frame()
                    roiname = ROI
                    if len(self.Channels) == 1:
                        if '1' in self.Channels[0]:
                            Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                                 roiname,
                                                                 1,
                                                                 self.mean_Photons_ch_1,
                                                                 self.mean_Photons_err_ch_1,
                                                                 self.mean_Molecules_ch_1,
                                                                 self.mean_Molecules_err_ch_1,
                                                                 self.mean_Concentration_ch_1,
                                                                 self.mean_Concentration_err_ch_1,
                                                                 self.median_C_ch_1,
                                                                 self.median_err_C_ch_1,
                                                                 self.mean_Background_Photons_ch_1,
                                                                 self.mean_Background_Photons_err_ch_1]],
                                                               columns=self._base_result_columns())
                          

                        elif '2' in self.Channels[0]:
                            Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                                 roiname,
                                                                 2,
                                                                 self.mean_Photons_ch_2,
                                                                 self.mean_Photons_err_ch_2,
                                                                 self.mean_Molecules_ch_2,
                                                                 self.mean_Molecules_err_ch_2,
                                                                 self.mean_Concentration_ch_2,
                                                                 self.mean_Concentration_err_ch_2,
                                                                 self.median_C_ch_2,
                                                                 self.median_err_C_ch_2,
                                                                 self.mean_Background_Photons_ch_2,
                                                                 self.mean_Background_Photons_err_ch_2]],
                                                               columns=self._base_result_columns())
                          
                        else:
                            pass

                    elif len(self.Channels) == 2:
                        Sing_Results_DF_tmp = pd.DataFrame([[self.anal_file,
                                                             roiname,
                                                             1,
                                                             self.mean_Photons_ch_1,
                                                             self.mean_Photons_err_ch_1,
                                                             self.mean_Molecules_ch_1,
                                                             self.mean_Molecules_err_ch_1,
                                                             self.mean_Concentration_ch_1,
                                                             self.mean_Concentration_err_ch_1,
                                                             self.median_C_ch_1,
                                                             self.median_err_C_ch_1,
                                                             self.mean_Background_Photons_ch_1,
                                                             self.mean_Background_Photons_err_ch_1],
                                                            [self.anal_file,
                                                             roiname,
                                                             2,
                                                             self.mean_Photons_ch_2,
                                                             self.mean_Photons_err_ch_2,
                                                             self.mean_Molecules_ch_2,
                                                             self.mean_Molecules_err_ch_2,
                                                             self.mean_Concentration_ch_2,
                                                             self.mean_Concentration_err_ch_2,
                                                             self.median_C_ch_2,
                                                             self.median_err_C_ch_2,
                                                             self.mean_Background_Photons_ch_2,
                                                             self.mean_Background_Photons_err_ch_2]],
                                                           columns=self._base_result_columns())
                      
                    Sing_Results_DF_tmp = self._attach_frame_results(
                        Sing_Results_DF_tmp
                    )
                    self.Sing_Results_DF = pd.concat([self.Sing_Results_DF, Sing_Results_DF_tmp]).reset_index(drop=True)
                self._pkl_file()
                ptu_path = os.path.join(self.PTU_directory, an_file + '.ptu')
                self.last_batch_file_timings.append({
                    'filename': an_file + '.ptu',
                    'size_bytes': os.path.getsize(ptu_path),
                    'wall_time_seconds': time.perf_counter() - file_started,
                })

    def callback_directory_select(self, sender, app_data):
        self.files = ()
        self.directory = app_data['file_path_name']
        self.PTU_directory = self.directory
        self.new_directory = self.directory
        self.last_directory = self.directory
        self.update_dialogs_default_directory(self.last_directory)
        self.files = tuple(np.sort([f for f in os.listdir(self.directory) if f.endswith('.ptu')]))
        if len(files) == 0:
            show_error_no_files('No PTU files found.')
        else:
            self.update_flist(self.files)
        self.anal_file = files[0]
        dpg.configure_item('file_box', default_value=self.anal_file)

    def callback_empty(self, sender, app_data):
        '''Empty function. Do nothing.'''
        pass

    def callback_kappa_err_input(self, sender, app_data):

        if sender == 'kappa_err_input_ch_1':
            omega = dpg.get_value('omega_input_ch_1')
            omega_err = dpg.get_value('omega_err_input_ch_1')
            kappa = dpg.get_value('kappa_input_ch_1')
            kappa_err = app_data
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_1', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_1', default_value=foc_vol[1])
        else:
            omega = dpg.get_value('omega_input_ch_2')
            omega_err = dpg.get_value('omega_err_input_ch_2')
            kappa = dpg.get_value('kappa_input_ch_2')
            kappa_err = app_data
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_2', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_2', default_value=foc_vol[1])

    def callback_kappa_input(self, sender, app_data):

        if sender == 'kappa_input_ch_1':
            omega = dpg.get_value('omega_input_ch_1')
            omega_err = dpg.get_value('omega_err_input_ch_1')
            kappa = app_data
            kappa_err = dpg.get_value('kappa_err_input_ch_1')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_1', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_1', default_value=foc_vol[1])
        else:
            omega = dpg.get_value('omega_input_ch_2')
            omega_err = dpg.get_value('omega_err_input_ch_2')
            kappa = app_data
            kappa_err = dpg.get_value('kappa_err_input_ch_2')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_2', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_2', default_value=foc_vol[1])

    @staticmethod
    def _current_calibration_widget_values():
        tags = (
            'omega_input_ch_1', 'omega_err_input_ch_1',
            'kappa_input_ch_1', 'kappa_err_input_ch_1',
            'focal_vol_input_ch_1', 'focal_vol_err_input_ch_1',
            'Brightness_input_ch_1', 'Brightness_err_input_ch_1',
            'omega_input_ch_2', 'omega_err_input_ch_2',
            'kappa_input_ch_2', 'kappa_err_input_ch_2',
            'focal_vol_input_ch_2', 'focal_vol_err_input_ch_2',
            'Brightness_input_ch_2', 'Brightness_err_input_ch_2',
        )
        return {tag: dpg.get_value(tag) for tag in tags}

    def callback_listbox(self, sender, app_data, calibration=None):
        self.anal_file = app_data
        # print(app_data)
        pkl_file = self.anal_file + '.rpk'
        pkl_path = os.path.join(self.PTU_directory, pkl_file)
        if os.path.exists(pkl_path):
            self.pkl = self._load_pkl_file(pkl_path)

        else:
            self.pkl = {}

        # Calculate-all applies the calibration visible when the batch starts.
        # Per-file RPK metadata must not replace a newly loaded calibration.
        if calibration is not None:
            for tag, value in calibration.items():
                dpg.set_value(tag, value)

        self.load_PTU_images(self.anal_file)
        self.hide_histograms()
        self.callback_calculate(sender, app_data)

    def callback_no_files_dialog_close_only(self, sender, app_data):
        dpg.configure_item('No_data_files', show=False)
        dpg.delete_item('no_files_error_text')
        dpg.delete_item('no_files_error_butt')
        dpg.delete_item('No_data_files')

    def callback_omega_err_input(self, sender, app_data):

        if sender == 'omega_err_input_ch_1':
            omega = dpg.get_value('omega_input_ch_1')
            omega_err = app_data
            kappa = dpg.get_value('kappa_input_ch_1')
            kappa_err = dpg.get_value('kappa_err_input_ch_1')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_1', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_1', default_value=foc_vol[1])
        else:
            omega = dpg.get_value('omega_input_ch_2')
            omega_err = app_data
            kappa = dpg.get_value('kappa_input_ch_2')
            kappa_err = dpg.get_value('kappa_err_input_ch_2')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_2', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_2', default_value=foc_vol[1])

    def callback_omega_input(self, sender, app_data):

        if sender == 'omega_input_ch_1':
            omega = app_data
            omega_err = dpg.get_value('omega_err_input_ch_1')
            kappa = dpg.get_value('kappa_input_ch_1')
            kappa_err = dpg.get_value('kappa_err_input_ch_1')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_1', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_1', default_value=foc_vol[1])
        else:
            omega = app_data
            omega_err = dpg.get_value('omega_err_input_ch_2')
            kappa = dpg.get_value('kappa_input_ch_2')
            kappa_err = dpg.get_value('kappa_err_input_ch_2')
            foc_vol = self.VEFF(omega, kappa, omega_err, kappa_err)
            dpg.configure_item('focal_vol_input_ch_2', default_value=foc_vol[0])
            dpg.configure_item('focal_vol_err_input_ch_2', default_value=foc_vol[1])

    def callback_remove_result_button(self, sender, app_data):
        if sender == 'remove_button_results_ch_1':
            ind_result_to_remove = []
            for i in self.FCS_results_ch_1.index:
                if dpg.get_value('ch_1_results_delete_' + str(i) + '_check_ch_1'):
                    ind_result_to_remove.append(i)

            self.FCS_results_ch_1.drop(self.FCS_results_ch_1.index[ind_result_to_remove], inplace=True)
            self.FCS_results_ch_1.reset_index(drop=True, inplace=True)
            self.mean_bright_input_ch_1()
            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_1_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_1_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for i in self.FCS_results_ch_1.index:
                with dpg.table_row(tag='ch_1_row_results_show_ch_1' + str(i),
                                   parent='table_results_show_ch_1'):
                    dpg.add_text(self.FCS_results_ch_1.at[i, 'file'],
                                 tag='ch_1_results_show_' + str(i) + '_name_ch_1')
                    dpg.add_text(np.round(self.FCS_results_ch_1.at[i, 'N_p'], 2),
                                 tag='ch_1_results_show_' + str(i) + '_N_p_value_ch_1')
                    dpg.add_text(self.FCS_results_ch_1.at[i, 'Brightness'],
                                 tag='ch_1_results_show_' + str(i) + '_Brightness_value_ch_1')
                    dpg.add_checkbox(label='',
                                     tag='ch_1_results_delete_' + str(i) + '_check_ch_1')
        else:
            ind_result_to_remove = []
            for i in self.FCS_results_ch_2.index:
                if dpg.get_value('ch_2_results_delete_' + str(i) + '_check_ch_2'):
                    ind_result_to_remove.append(i)
            self.FCS_results_ch_2.drop(self.FCS_results_ch_2.index[ind_result_to_remove], inplace=True)
            self.FCS_results_ch_2.reset_index(drop=True, inplace=True)
            self.mean_bright_input_ch_2()
            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_results_show_'):
                    try:

                        dpg.delete_item(alias)
                    except:
                        pass
                if alias.startswith('ch_2_results_delete_'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for alias in dpg.get_aliases():
                if alias.startswith('ch_2_row_results_show'):
                    try:
                        dpg.delete_item(alias)
                    except:
                        pass
            for i in self.FCS_results_ch_2.index:
                with dpg.table_row(tag='ch_2_row_results_show_ch_2' + str(i),
                                   parent='table_results_show_ch_2'):
                    dpg.add_text(self.FCS_results_ch_2.at[i, 'file'],
                                 tag='ch_2_results_show_' + str(i) + '_name_ch_2')
                    dpg.add_text(np.round(self.FCS_results_ch_2.at[i, 'N_p'], 2),
                                 tag='ch_2_results_show_' + str(i) + '_N_p_value_ch_2')
                    dpg.add_text(self.FCS_results_ch_2.at[i, 'Brightness'],
                                 tag='ch_2_results_show_' + str(i) + '_Brightness_value_ch_2')
                    dpg.add_checkbox(label='',
                                     tag='ch_2_results_delete_' + str(i) + '_check_ch_2')

    def callback_reset_results_DF(self):
        self.initialize_res_df()
        files = os.listdir(self.PTU_directory)
        files = [f for f in files if f.endswith('.rpk')]
        for f in files:
            os.remove(os.path.join(self.PTU_directory, f))

    def callback_select_roi(self, sender, app_data):

        if dpg.get_value(sender):
            dpg.set_value('Auto_ROI_checkbox', False)
            dpg.hide_item('ROI_name_tag')
            dpg.show_item('ROI_names_combo_tag')
            self.callback_select_autoroi('Auto_ROI_checkbox', False)
            if self.ROI_directory != None and len(self.ROI_directory) != 0:
                try:
                    self.load_PTU_images(self.anal_file)
                except:
                    self.show_error_no_files('Seems there is no ROI folder selected. Try again.')

            else:
                dpg.show_item('ROI_folder_dialog_id')
        else:
            dpg.show_item('ROI_name_tag')
            dpg.hide_item('ROI_names_combo_tag')
            self.load_PTU_images(self.anal_file)

        self.get_roi_state()

    def callback_select_autoroi(self, sender, app_data):
        if dpg.get_value(sender):
            dpg.set_value('FILE_ROI_checkbox', False)
            dpg.show_item('ROI_name_tag')
            dpg.hide_item('ROI_names_combo_tag')
            dpg.show_item('auto_ROI_ch_table')
            dpg.configure_item('cell_thres_ratio_1', enabled=True)
            dpg.configure_item('nucl_thres_ratio_1', enabled=True)
            dpg.configure_item('ROI_mode_1', enabled=True)
            dpg.configure_item('cp_roi_1', enabled=True)
            dpg.configure_item('cell_thres_ratio_2', enabled=True)
            dpg.configure_item('nucl_thres_ratio_2', enabled=True)
            dpg.configure_item('ROI_mode_2', enabled=True)
            dpg.configure_item('cp_roi_2', enabled=True)
            self.mode_init.file_box['num_items'] = 8
            self.mode_init.PTU_DATA_window['height'] = int(350 * self.mode_init.size_ratio['height'])
            self.mode_init.file_window['pos'] = (self.mode_init.left_indent,
                                                 self.mode_init.top_indent + self.mode_init.PTU_DATA_window[
                                                     'height'] + self.mode_init.internal_indent)
            dpg.configure_item('file_box', num_items=self.mode_init.file_box['num_items'])
            dpg.configure_item('PTU_DATA_window', height=self.mode_init.PTU_DATA_window['height'])
            dpg.configure_item('file_window',
                               pos=self.mode_init.file_window['pos'])
            self.mode_init.file_window['height'] = dpg.get_viewport_height() - (
                    self.mode_init.top_indent + dpg.get_item_height(
                'PTU_DATA_window') + self.mode_init.internal_indent + self.mode_init.bottom_indent)
            dpg.configure_item('file_window',
                               height=self.mode_init.file_window['height'])


        else:
            
            dpg.hide_item('auto_ROI_ch_table')
            dpg.configure_item('cell_thres_ratio_1', enabled=False)
            dpg.configure_item('nucl_thres_ratio_1', enabled=False)
            dpg.configure_item('ROI_mode_1', enabled=False)
            dpg.configure_item('cp_roi_1', enabled=False)
            dpg.configure_item('cell_thres_ratio_2', enabled=False)
            dpg.configure_item('nucl_thres_ratio_2', enabled=False)
            dpg.configure_item('ROI_mode_2', enabled=False)
            dpg.configure_item('cp_roi_2', enabled=False)
            self.mode_init.file_box['num_items'] = 11
            self.mode_init.PTU_DATA_window['height'] = int(175 * self.mode_init.size_ratio['height'])
            self.mode_init.file_window['pos'] = (self.mode_init.left_indent,
                                                 self.mode_init.top_indent + self.mode_init.PTU_DATA_window[
                                                     'height'] + self.mode_init.internal_indent)
            dpg.configure_item('file_box', num_items=self.mode_init.file_box['num_items'])
            dpg.configure_item('PTU_DATA_window', height=self.mode_init.PTU_DATA_window['height'])
            dpg.configure_item('file_window', pos=self.mode_init.file_window['pos'])
            self.mode_init.file_window['height'] = dpg.get_viewport_height() - (
                    self.mode_init.top_indent + dpg.get_item_height(
                'PTU_DATA_window') + self.mode_init.internal_indent + self.mode_init.bottom_indent)
            dpg.configure_item('file_window', height=self.mode_init.file_window['height'])
        self.get_roi_state()
        self.load_PTU_images(self.anal_file)

    def display_images(self, channel):

        self._ensure_display_subprocessors()
        if channel == 1:
            self._update_textures_both_roi('ch1', None)

        elif channel == 2:
            self._update_textures_both_roi('ch2', None)

        elif channel == 'both':
            self._update_textures_both_roi('ch1', None)
            self._update_textures_both_roi('ch2', None)

    def hide_histograms(self):
        dpg.set_value('c_dist_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('c_mean_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('c_med_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('np_dist_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('np_mean_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('np_med_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_dist_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_mean_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_med_ser_ch_1', (np.empty(2), np.empty(2)))
        dpg.configure_item('c_mean_ser_ch_1', label='Mean = ')
        dpg.configure_item('c_med_ser_ch_1', label='Median = ')
        dpg.configure_item('np_mean_ser_ch_1', label='Mean = ')
        dpg.configure_item('np_med_ser_ch_1', label='Median = ')
        dpg.configure_item('phot_mean_ser_ch_1', label='Mean = ')
        dpg.configure_item('phot_med_ser_ch_1', label='Median = ')
        dpg.hide_item('hist_conc_plot_ch1')
        dpg.hide_item('hist_np_plot_ch1')
        dpg.hide_item('hist_phot_plot_ch1')
        dpg.set_value('c_dist_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('c_mean_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('c_med_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('np_dist_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('np_mean_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('np_med_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_dist_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_mean_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.set_value('phot_med_ser_ch_2', (np.empty(2), np.empty(2)))
        dpg.configure_item('c_mean_ser_ch_2', label='Mean = ')
        dpg.configure_item('c_med_ser_ch_2', label='Median = ')
        dpg.configure_item('np_mean_ser_ch_2', label='Mean = ')
        dpg.configure_item('np_med_ser_ch_2', label='Median = ')
        dpg.configure_item('phot_mean_ser_ch_2', label='Mean = ')
        dpg.configure_item('phot_med_ser_ch_2', label='Median = ')
        dpg.hide_item('hist_conc_plot_ch2')
        dpg.hide_item('hist_np_plot_ch2')
        dpg.hide_item('hist_phot_plot_ch2')

    def import_ROI(self, sender, app_data, user_data):

        self.directory = app_data['file_path_name']
        self.new_directory = self.directory
        self.last_directory = self.directory
        self.update_dialogs_default_directory(self.last_directory)
        roi = self.load_ROI(app_data['file_path_name'])
        if user_data == 'Add_ROI_1_button':
            try:
                self.roi_1 = roi.to_numpy()
                self.DF = self.DF * self.roi_1
                chan = 1

            except:
                self.show_error_no_files('PTU file loaded. Try again.')
        if user_data == 'Add_ROI_2_button':
            try:
                self.roi_2 = roi.to_numpy()
                self.DF2 = self.DF2 * self.roi_2
                chan = 2
            except:
                self.show_error_no_files('PTU file loaded. Try again.')

        if len(self.pck_list) == 2:
            chan = 'both'
            self.display_images(chan)
        else:
            self.display_images(chan)

    def check_for_roi_files(self, path_to_search, anfile):
        try:
            roi_files = os.listdir(path_to_search)
        except:
            self.show_error_no_files('Seems there is no ROI folder selected. Try again.')
            return
        roi_files = [f for f in roi_files if anfile in f]
        roi_files = [f for f in roi_files if '_roi' in f]
        rois = []
        for f in roi_files:
            roi_n = f.split('_')
            roi_n = [r for r in roi_n if r.startswith('roi')]
            roicnt = roi_n[0].replace('roi', '')
            if len(roicnt) != 0:
                roin = 'ROI_' + roicnt
            else:
                roin = 'ROI_' + str(0)
            
            rois.append(roin)
            
        roiset = list(set(rois))
        roiset.sort()
        output = {k: {} for k in roiset}
        for rs in roiset:
            rn = rs[-1]
            chns = []
            for f in roi_files:
                if 'roi' + rn in f:
                    ch = f.split('_ch_')
                    ch = [r for r in ch if r.endswith('.dat')][0][0]
                    output[rs]['ch_' + ch] = f

        return output

    def callback_ROI_names_combo(self, sender, app_data):
        ROIn = app_data
        roin = ROIn.replace('ROI_', '')
        if len(self.Channels) == 1:
            if '1' in self.Channels[0]:
                roi_1_path = os.path.join(self.ROI_directory, self.anal_file + '_roi' + roin + '_ch_1.dat')
                if os.path.exists(roi_1_path):
                    pass
                else:
                    roi_1_path = os.path.join(self.ROI_directory, self.anal_file + '_roi_ch_1.dat')
                self.roi_1 = self.load_ROI(roi_1_path).to_numpy()
                self.processor_1.roi_image = self.roi_1
                self.image_1_times_roi = self.Current_image_1
                self.display_images('both')
            elif '2' in self.Channels[0]:
                roi_2_path = os.path.join(self.ROI_directory, self.anal_file + '_roi' + roin + '_ch_2.dat')
                if os.path.exists(roi_2_path):
                    pass
                else:
                    roi_2_path = os.path.join(self.ROI_directory, self.anal_file + '_roi_ch_2.dat')
                self.roi_2 = self.load_ROI(roi_2_path).to_numpy()
                self.processor_2.roi_image = self.roi_2
                self.image_2_times_roi = self.Current_image_2
                self.display_images('both')
        elif len(self.Channels) == 2:
            roi_1_path = os.path.join(self.ROI_directory, self.anal_file + '_roi' + roin + '_ch_1.dat')
            if os.path.exists(roi_1_path):
                pass
            else:
                roi_1_path = os.path.join(self.ROI_directory, self.anal_file + '_roi_ch_1.dat')
            self.roi_1 = self.load_ROI(roi_1_path).to_numpy()
            self.processor_1.roi_image = self.roi_1
            self.image_1_times_roi = self.Current_image_1
            roi_2_path = os.path.join(self.ROI_directory, self.anal_file + '_roi' + roin + '_ch_2.dat')
            if os.path.exists(roi_2_path):
                pass
            else:
                roi_2_path = os.path.join(self.ROI_directory, self.anal_file + '_roi_ch_2.dat')
            self.roi_2 = self.load_ROI(roi_2_path).to_numpy()
            self.processor_2.roi_image = self.roi_2
            self.image_2_times_roi = self.Current_image_2
            self.display_images('both')

    def load_PTU_images(self, an_file):
        self.pkl_data = {}
        self._reset_loaded_file_results()
        dpg.set_value('ROI_name_tag', 'ROI_0')
        pickle_file = os.path.join(self.PTU_directory, an_file + '.pkl')
        with open(pickle_file, 'rb') as pcklf:
            pklf = pickle.load(pcklf)
        self.pkl_data = pklf
        self.decay_display_ranges = {'1': None, '2': None}
        self.decay_display_bounds = {'1': (0.0, 1.0), '2': (0.0, 1.0)}
        self.decay_display_offsets = {'1': 0.0, '2': 0.0}
        self.decay_display_is_pie = {'1': False, '2': False}
        self._initialize_decay_display_ranges()

        ptu_meta = pklf['File info']
        try:
            self.DF = self.DF2 = []
        except:
            pass

        self.PTU_Resolution = str(ptu_meta['Pixels per line']) + 'x' + str(ptu_meta['Number of lines'])
        self.PTU_Px_size = ptu_meta['Pixels size']
        displayed_frame_count = int(ptu_meta['Number of frames'])
        self.PTU_N_frames = resolve_integrated_frame_count(ptu_meta)
        self.PTU_Px_dwell = ptu_meta['Pixel dwell']
        dpg.set_value('Resolution_output', 'Resolution: ' + self.PTU_Resolution)
        dpg.set_value('Pixel_size_output', self.PTU_Px_size)
        dpg.set_value('Nframes_output', displayed_frame_count)
        dpg.set_value('Pixel_dwell_output', self.PTU_Px_dwell)
        dpg.set_value('sinle_phot_output_ch_1', 0)
        dpg.set_value('sinle_phot_err_output_ch_1', 0)
        dpg.set_value('sinle_mols_output_ch_1', 0)
        dpg.set_value('sinle_mols_err_output_ch_1', 0)
        dpg.set_value('single_conc_output_ch_1', 0)
        dpg.set_value('single_conc_err_output_ch_1', 0)
        dpg.set_value('sinle_phot_output_ch_2', 0)
        dpg.set_value('sinle_phot_err_output_ch_2', 0)
        dpg.set_value('sinle_mols_output_ch_2', 0)
        dpg.set_value('sinle_mols_err_output_ch_2', 0)
        dpg.set_value('single_conc_output_ch_2', 0)
        dpg.set_value('single_conc_err_output_ch_2', 0)
        ptu_files = list(np.sort([f for f in os.listdir(self.PTU_directory) if f.endswith('.ptu')]))
        self.Channels = list(pklf.keys())
        self.Channels = [f for f in self.Channels if f.startswith('export_df')]
        self.Channels = [ch[-1] for ch in self.Channels]
        use_file_roi = bool(dpg.get_value('FILE_ROI_checkbox'))
        if use_file_roi:
            existing_rois = self.check_for_roi_files(self.ROI_directory, an_file) or {}
            roi_names = list(existing_rois.keys())
            dpg.configure_item('ROI_names_combo_tag', items=roi_names)
            if roi_names:
                dpg.set_value('ROI_names_combo_tag', roi_names[0])
            else:
                use_file_roi = False
                dpg.set_value('FILE_ROI_checkbox', False)
                dpg.set_value('ROI_names_combo_tag', '')

        if use_file_roi:
            if len(self.Channels) == 1:
                if '1' in self.Channels[0]:
                    Intensity_1 = pklf['intensity_1']
                    Lifetime_1 = pklf['lifetimes_1']

                    Intensity_1 = Intensity_1
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = self._calculation_intensity(Intensity_1)
                    
                    roi_1_path = os.path.join(self.ROI_directory, an_file + '_roi_ch_1.dat')
                    if os.path.exists(roi_1_path):
                        pass
                    else:
                        ROIn = dpg.get_value('ROI_names_combo_tag')
                        roin = ROIn.replace('ROI_', '')
                        roi_1_path = os.path.join(self.ROI_directory, an_file + '_roi'+roin+'_ch_1.dat')

                    self.roi_1 = self.load_ROI(roi_1_path).to_numpy()
                    self.processor_1.roi_image = self.roi_1
                    Intensity_1 = Intensity_1
                    channel = 'both'
                    self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                    self.image_1_times_roi = self.Current_image_1
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_2 = self.NO_IMAGE_INTENSITY
                    self.display_images(channel)

                elif '2' in self.Channels[0]:
                    Intensity_2 = pklf['intensity_2']
                    Intensity_2 = Intensity_2
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = self._calculation_intensity(Intensity_2)
                    roi_2_path = os.path.join(self.ROI_directory, an_file + '_roi_ch_2.dat')
                    if os.path.exists(roi_2_path):
                        pass
                    else:
                        ROIn = dpg.get_value('ROI_names_combo_tag')
                        roin = ROIn.replace('ROI_', '')
                        roi_2_path = os.path.join(self.ROI_directory, an_file + '_roi'+roin+'_ch_2.dat')

                    self.roi_2 = self.load_ROI(roi_2_path).to_numpy()
                    self.processor_2.roi_image = self.roi_2
                    channel = 'both'
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_1 = self.NO_IMAGE_INTENSITY
                    self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                    self.image_2_times_roi = self.Current_image_2
                    self.display_images(channel)
                else:
                    pass

            elif len(self.Channels) == 2:
                Intensity_1 = pklf['intensity_1']
                Intensity_2 = pklf['intensity_2']
                self.processor_1 = ImageROIProcessor()
                self.processor_1.image = self._calculation_intensity(Intensity_1)
                self.processor_2 = ImageROIProcessor()
                self.processor_2.image = self._calculation_intensity(Intensity_2)
                roi_1_path = os.path.join(self.ROI_directory, an_file + '_roi_ch_1.dat')
                if os.path.exists(roi_1_path):
                    pass
                else:
                    ROIn = dpg.get_value('ROI_names_combo_tag')
                    roin = ROIn.replace('ROI_', '')
                    roi_1_path = os.path.join(self.ROI_directory, an_file + '_roi'+roin+'_ch_1.dat')

                self.roi_1 = self.load_ROI(roi_1_path).to_numpy()
                roi_2_path = os.path.join(self.ROI_directory, an_file + '_roi_ch_2.dat')
                if os.path.exists(roi_2_path):
                    pass
                else:
                    OIn = dpg.get_value('ROI_names_combo_tag')
                    roin = ROIn.replace('ROI_', '')
                    roi_2_path = os.path.join(self.ROI_directory, an_file + '_roi'+roin+'_ch_2.dat')

                self.roi_2 = self.load_ROI(roi_2_path).to_numpy()
                self.processor_1.roi_image = self.roi_1
                self.processor_2.roi_image = self.roi_2
                channel = 'both'
                self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                self.image_1_times_roi = self.Current_image_1
                self.image_2_times_roi = self.Current_image_2
                self.display_images(channel)

        elif dpg.get_value('Auto_ROI_checkbox'):

            if len(self.Channels) == 1:
                dpg.configure_item('cp_roi_1', enabled=False)
                dpg.configure_item('cp_roi_2', enabled=False)
                dpg.set_value('cp_roi_1', False)
                dpg.set_value('cp_roi_2', False)
                if '1' in self.Channels[0]:
                    Intensity_1 = pklf['intensity_1']
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = self._calculation_intensity(Intensity_1)
                    channel = 'both'
                    self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                    self.image_1_times_roi = self.Current_image_1
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_2 = self.NO_IMAGE_INTENSITY
                    self.display_images(channel)

                elif '2' in self.Channels[0]:
                    Intensity_2 = pklf['intensity_2']
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = self._calculation_intensity(Intensity_2)
                    channel = 'both'
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_1 = self.NO_IMAGE_INTENSITY
                    self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                    self.image_2_times_roi = self.Current_image_2
                    self.display_images(channel)

                else:
                    pass

            elif len(self.Channels) == 2:
                dpg.configure_item('cp_roi_1', enabled=True)
                dpg.configure_item('cp_roi_2', enabled=True)
                Intensity_1 = pklf['intensity_1']
                Intensity_2 = pklf['intensity_2']
                self.processor_1 = ImageROIProcessor()
                self.processor_1.image = self._calculation_intensity(Intensity_1)
                self.processor_2 = ImageROIProcessor()
                self.processor_2.image = self._calculation_intensity(Intensity_2)
                channel = 'both'
                self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                self.image_1_times_roi = self.Current_image_1
                self.image_2_times_roi = self.Current_image_2
                self.display_images(channel)

        else:

            if len(self.Channels) == 1:
                if '1' in self.Channels[0]:
                    Intensity_1 = pklf['intensity_1']
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = self._calculation_intensity(Intensity_1)
                    self.roi_1 = np.zeros(self.Current_image_1.shape)
                    channel = 'both'
                    self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                    self.image_1_times_roi = self.Current_image_1
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_2 = self.NO_IMAGE_INTENSITY
                    self.display_images(channel)

                elif '2' in self.Channels[0]:
                    Intensity_2 = pklf['intensity_2']
                    self.processor_2 = ImageROIProcessor()
                    self.processor_2.image = self._calculation_intensity(Intensity_2)
                    self.roi_2 = np.zeros(self.Current_image_2.shape)
                    self.image_2_times_roi = self.Current_image_2
                    channel = 'both'
                    self.processor_1 = ImageROIProcessor()
                    self.processor_1.image = np.clip((self.NO_IMAGE_INTENSITY), 0, 1).astype(np.float64)
                    self.Current_image_1 = self.NO_IMAGE_INTENSITY
                    self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                    self.display_images(channel)

                else:
                    pass

            elif len(self.Channels) == 2:

                Intensity_1 = pklf['intensity_1']
                Intensity_2 = pklf['intensity_2']
                self.roi_1 = np.zeros(self.Current_image_1.shape)
                self.roi_2 = np.zeros(self.Current_image_2.shape)
                self.processor_1 = ImageROIProcessor()
                self.processor_1.image = self._calculation_intensity(Intensity_1)
                self.processor_2 = ImageROIProcessor()
                self.processor_2.image = self._calculation_intensity(Intensity_2)
                channel = 'both'
                self.Current_image_1 = Intensity_1 / np.max(Intensity_1)
                self.Current_image_2 = Intensity_2 / np.max(Intensity_2)
                self.image_1_times_roi = self.Current_image_1
                self.image_2_times_roi = self.Current_image_2
                self.display_images(channel)

        self._ensure_display_subprocessors()
        for channel_number in ('1', '2'):
            self._synchronize_display_roi(channel_number)

        self.callback_DISP_OPT_combo(None, self.display_option)

    def overlayrgba(self, im, rgba_image, mask_image, full_mask, ovrl):
        overlay_alpha = ovrl
        alpha_normalized = np.clip(overlay_alpha / 100.0, 0., 1.).astype(np.float64)
        if alpha_normalized == 1:
            mask_image[full_mask > 0, 0] = 1
        else:
            mask_image[full_mask > 0, 0] = (
                    im[full_mask > 0] * (1 - alpha_normalized) + 1 * alpha_normalized
            ).astype(np.float64)

        mask_image[full_mask > 0, 1] = im[full_mask > 0].astype(np.float64)
        mask_image[full_mask > 0, 2] = im[full_mask > 0].astype(np.float64)
        mask_image[full_mask > 0, 3] = (alpha_normalized).astype(np.float64)

        for i in range(3):
            rgba_image[..., i] = (rgba_image[..., i] * (1 - alpha_normalized) + mask_image[..., i] * alpha_normalized)

        rgba_image[..., 3] = np.maximum(rgba_image[..., 3], mask_image[..., 3])
        rgba_image = np.clip(rgba_image, 0, 1)

        return rgba_image

    def rgba_to_dpgtex(self, rgba_image, gs_im_max, tex_name):

        w = dpg.get_item_width(tex_name)
        h = dpg.get_item_height(tex_name)
        rgba_image = cv2.resize(rgba_image, (w, h), interpolation=cv2.INTER_LINEAR)
        normalization = float(gs_im_max) if np.isfinite(gs_im_max) and gs_im_max > 0 else 1.0
        rgba_image = rgba_image.astype(np.float64) / normalization
        new_texture_data = rgba_image.flatten().tolist()
        dpg.set_value(tex_name, new_texture_data)

    def onHover(self, sender, app_data, user_data):

        dpg.focus_item(user_data)

    def get_ui_state(self, channel):
        """Get UI state parameters for a specific channel"""
        foreground_processor = getattr(self, f'processor_{channel}')
        display_processor = self._get_display_processor(channel)
        ui_state = {
            'auto_roi': dpg.get_value('Auto_ROI_checkbox'),
            'file_roi': dpg.get_value('FILE_ROI_checkbox'),
            'cp': dpg.get_value(f'cp_roi_{channel}'),
            'multiple_cells_checkbox': dpg.get_value(f'multiple_cells_checkbox_{channel}'),
            'processor': foreground_processor,
            'display_processor': display_processor,
            'tex_name': getattr(self, f'tex_{channel}_name'),
            'image_times_roi': f'image_{channel}_times_roi',
            'contrast': dpg.get_value(f'img_contrast_{channel}'),
            'brightness': dpg.get_value(f'img_Brightness_{channel}') / 255,
            'ovrl': dpg.get_value(f'img_roi_alpha_{channel}'),
            'cell_thres_ratio': dpg.get_value(f'cell_thres_ratio_{channel}'),
            'nucl_thres_ratio': dpg.get_value(f'nucl_thres_ratio_{channel}'),
            'find_roi_mode': dpg.get_value(f'ROI_mode_{channel}')
        }

        return ui_state

    def _process_file_roi(self, channel, disp, ui_state):
        processor = ui_state['processor']
        display_processor = ui_state['display_processor']
        roi = processor.roi_image
        if dpg.get_value('FILE_ROI_checkbox') and roi is not None:
            img = display_processor.image
            full_mask = np.nan_to_num(roi * 255, nan=0)
            setattr(self, f'image_{channel}_times_roi', img * roi)
            setattr(processor, 'all_masks', [full_mask])
            self._update_texture(channel, disp, ui_state)
        else:
            self._process_no_roi(channel, disp, ui_state)

    def process_channel(self, channel, ui_state):
        """Process image channel using centralized UI state"""

        self._synchronize_display_roi(channel)
        processor = ui_state['processor']
        display_processor = self._get_display_processor(channel)
        ui_state['display_processor'] = display_processor
        disp = self._normalized_display_image(display_processor.image, processor.image, channel)
        if ui_state['auto_roi']:
            if len(self.Channels) == 1:
                if channel == self.Channels[0]:
                    self._process_auto_roi(channel, disp, ui_state)
                else:
                    pass
            else:
                self._process_auto_roi(channel, disp, ui_state)
        elif ui_state['file_roi']:
            if len(self.Channels) == 1:
                if channel == self.Channels[0]:
                    self._process_file_roi(channel, disp, ui_state)
                else:
                    pass
            else:
                self._process_file_roi(channel, disp, ui_state)
        else:
            self._process_no_roi(channel, disp, ui_state)

    def _update_textures_both_roi(self, sender, app_data):
        
        if sender.endswith(('1', '2')):

            channel = sender[-1]
            self.process_channel(channel, self.get_ui_state(channel))
        else:

            for channel in self.Channels:
                self.process_channel(channel, self.get_ui_state(channel))

        self.callback_calculate(sender, None)

    def _image_buttons_controller(self, sender):

        channel = sender[-1]
        ui_state = self.get_ui_state(channel)
        display_processor = ui_state['display_processor']
        disp = self._normalized_display_image(
            display_processor.image,
            ui_state['processor'].image,
            channel,
        )
        self._update_texture(channel, disp, ui_state)

    def copy_roi_from_channel(self, sender):

        copy_to_channel = sender[-1]
        copy_from_channel = '2' if copy_to_channel == '1' else '1'
        with dpg.mutex():
            if dpg.get_value(sender):
                dpg.set_value(f'cp_roi_{copy_from_channel}', False)

        if dpg.get_value(sender):

            copy_from_processor = getattr(self, f'processor_{copy_from_channel}')
            copy_to_processor = getattr(self, f'processor_{copy_to_channel}')
            setattr(copy_to_processor, 'all_cells_masks', copy_from_processor.all_masks.copy())
            setattr(copy_to_processor, 'all_masks', copy_from_processor.all_masks.copy())
            setattr(copy_to_processor, 'all_contours', copy_from_processor.all_contours.copy())
            copy_ui_state = self.get_ui_state(copy_to_channel)
            display_processor = copy_ui_state['display_processor']
            disp = self._normalized_display_image(
                display_processor.image,
                copy_to_processor.image,
                copy_to_channel,
            )
            dpg.configure_item(f'cell_thres_ratio_{copy_to_channel}', enabled=False)
            self._update_texture(copy_to_channel, disp, copy_ui_state)


        else:

            dpg.configure_item(f'cell_thres_ratio_{copy_to_channel}', enabled=True)
            self.process_channel(copy_to_channel, self.get_ui_state(copy_to_channel))

        self.callback_calculate(sender, None)

    def _process_auto_roi(self, channel, disp, ui_state):
        """Detect an automatic ROI from the foreground intensity image."""
        processor = ui_state['processor']
        froi = np.clip(processor.image, 0, 255).astype(np.uint8)
        self._get_cell_roi(channel, froi, ui_state)
        self._update_texture(channel, disp, ui_state)

    def _get_cell_roi(self, channel, froi, ui_state):
        """Get cell ROI using parameters from UI state"""

        processor = ui_state['processor']
        processor.detect_cell_roi(froi, ui_state['cell_thres_ratio'])

        if not processor.all_cells_masks:
            processor.all_cells_masks = [np.zeros_like(froi, dtype=np.uint8)]
            processor.all_cells_contours = []
        elif not ui_state['multiple_cells_checkbox']:
            processor.all_cells_contours = [processor.all_cells_contours[0]]
            processor.all_cells_masks = [processor.all_cells_masks[0]]

        processor.all_masks = processor.all_cells_masks
        processor.all_contours = processor.all_cells_contours

    def _roi_mode(self, sender, app_data, user_data):

        channel = sender[-1]
        ui_state = self.get_ui_state(channel)
        processor = ui_state['processor']
        option_choosen = dpg.get_value(f'ROI_mode_{channel}')
        drag_float_value = dpg.get_value(f'nucl_thres_ratio_{channel}')
        option_actions = {
            'subtract dark': {'params': {'mode': 'dark', 'many': False, 'subtract': True}},
            'find dark': {'params': {'mode': 'dark', 'many': False, 'subtract': False}},
            'subtract bright': {'params': {'mode': 'bright', 'many': False, 'subtract': True}},
            'find bright': {'params': {'mode': 'bright', 'many': False, 'subtract': False}},
            'subtract many dark spots': {'params': {'mode': 'dark', 'many': True, 'subtract': True}},
            'find many dark spots': {'params': {'mode': 'dark', 'many': True, 'subtract': False}},
            'subtract many bright spots': {'params': {'mode': 'bright', 'many': True, 'subtract': True}},
            'find many bright spots': {'params': {'mode': 'bright', 'many': True, 'subtract': False}},
        }

        option = option_actions.get(option_choosen)

        if option:

            processor.detect_objects_inside(threshold=drag_float_value, **option['params'])

        else:
            self.process_channel(channel, ui_state)

        disp = self._normalized_display_image(
            ui_state['display_processor'].image,
            ui_state['processor'].image,
            channel,
        )
        self._update_texture(channel, disp, ui_state)
        self.callback_calculate(sender, None)

    def _update_texture(self, channel, disp, ui_state):
        """Update texture using parameters from UI state"""
        processor = ui_state['processor']
        rgba_image = self._display_rgba(disp)
        adjusted_rgb = np.clip(rgba_image[..., :3] * ui_state['contrast'] + ui_state['brightness'], 0, 1)
        rgba_image[..., :3] = adjusted_rgb

        if hasattr(processor, 'all_masks') and processor.all_masks is not None:

            for cell_mask in processor.all_masks:
                rgba_image = self.overlayrgba(disp, rgba_image, rgba_image.copy(), cell_mask, ui_state['ovrl'])

        self.rgba_to_dpgtex(rgba_image, 1.0, ui_state['tex_name'])

    def _process_no_roi(self, channel, disp, ui_state):
        """Handle no ROI case using UI state"""
        display_processor = ui_state['display_processor']
        rgba_image = self._display_rgba(disp)
        adjusted_rgb = np.clip(rgba_image[..., :3] * ui_state['contrast'] + ui_state['brightness'], 0, 1)
        rgba_image[..., :3] = adjusted_rgb
        setattr(self, ui_state['image_times_roi'], display_processor.image)
        self.rgba_to_dpgtex(rgba_image, 1.0, ui_state['tex_name'])

    def _image_roi_at_mouse_position(self, image_tag):
        """Return channel state and the automatic ROI under the mouse pointer."""
        channel = '1' if image_tag.endswith('_1') else '2'
        ui_state = self.get_ui_state(channel)
        processor = ui_state['processor']
        if not processor.all_contours or not processor.all_masks:
            return channel, ui_state, None, None, None

        mouse_pos = dpg.get_mouse_pos()
        image_pos = dpg.get_item_pos(image_tag)
        displayed_width = dpg.get_item_width(image_tag)
        displayed_height = dpg.get_item_height(image_tag)
        if displayed_width <= 0 or displayed_height <= 0:
            return channel, ui_state, None, None, None

        original_height, original_width = processor.image.shape[:2]
        indent = dpg.get_item_configuration(image_tag)['indent']
        image_pos = (
            image_pos[0] + indent,
            image_pos[1] - self.img_height_shift['shift'],
        )
        x = int((mouse_pos[0] - image_pos[0]) * original_width / displayed_width)
        y = int((mouse_pos[1] - image_pos[1]) * original_height / displayed_height)
        if not (0 <= x < original_width and 0 <= y < original_height):
            return channel, ui_state, None, None, None

        for roi_index, contour in enumerate(processor.all_contours):
            if cv2.pointPolygonTest(contour, (x, y), False) >= 0:
                return (
                    channel,
                    ui_state,
                    roi_index,
                    contour,
                    processor.all_masks[roi_index],
                )
        return channel, ui_state, None, None, None

    def _channel_name_for_roi_export(self, channel):
        """Return the loaded channel label used in ROI filenames."""
        for channel_name in self.Channels:
            if channel in str(channel_name):
                return channel_name
        return f'ch{channel}'

    def on_image_click(self, sender, app_data, user_data):
        """Select one automatic ROI when multiple-cell mode is active."""
        image_tag, _ = user_data
        channel = '1' if image_tag.endswith('_1') else '2'
        if (
            not dpg.get_value('Auto_ROI_checkbox')
            or not dpg.get_value(f'multiple_cells_checkbox_{channel}')
        ):
            return

        channel, ui_state, roi_index, contour, roi_mask = (
            self._image_roi_at_mouse_position(image_tag)
        )
        if roi_mask is None:
            return

        processor = ui_state['processor']
        processor.all_contours = [contour]
        processor.all_masks = [roi_mask]
        processor.all_cells_contours = [contour]
        processor.all_cells_masks = processor.all_masks
        dpg.set_value('ROI_name_tag', f'ROI_{roi_index}')
        dpg.set_value(f'multiple_cells_checkbox_{channel}', False)
        display_processor = self._get_display_processor(channel)
        ui_state['display_processor'] = display_processor
        disp = self._normalized_display_image(
            display_processor.image,
            processor.image,
            channel,
        )
        self._update_texture(channel, disp, ui_state)
        self.callback_calculate(sender, None)

    def on_image_double_click(self, sender, app_data, user_data):
        """Export a single automatically detected ROI after a double click."""
        image_tag, _ = user_data
        channel = '1' if image_tag.endswith('_1') else '2'
        if (
            not dpg.get_value('Auto_ROI_checkbox')
            or dpg.get_value(f'multiple_cells_checkbox_{channel}')
        ):
            return

        channel, _, roi_index, _, roi_mask = self._image_roi_at_mouse_position(
            image_tag
        )
        if roi_mask is None:
            return
        current_roi_name = dpg.get_value('ROI_name_tag')
        if not current_roi_name or not current_roi_name.startswith('ROI_'):
            dpg.set_value('ROI_name_tag', f'ROI_{roi_index}')
        self.export_auto_roi(
            self._channel_name_for_roi_export(channel),
            np.asarray(roi_mask, dtype=np.uint8),
        )

    def load_ROI(self, path):

        df = pd.read_csv(path, sep='\t', header=None, skiprows=3, encoding='latin1')
        df = df.replace('-', -1.)
        try:
            df = df.astype(float)
        except:
            for i in df.index:
                try:
                    df.at[i, 0] = float(df.at[i, 0])

                except:
                    ind = i
                    break
            df = df[df.index < ind]
            df = df.astype(int)

        dfs = df[0].to_frame().applymap(np.isreal)
        if len(dfs.mask(dfs).dropna()) != 0:
            ind = int(dfs.mask(dfs).dropna().head(1).index.values)
            df = df[df.index < ind]
            df = df.astype(float)
            df = df.mask(df != -1, 1)
            df = df.where(df != -1, np.nan)

        else:
            df = df.astype(float)
            df = df.mask(df != -1, 1)
            df = df.where(df != -1, np.nan)

        return df

    def mean_bright_input_ch_1(self):
        self.mean_brightness_ch_1 = self.FCS_results_ch_1.Brightness.mean()
        self.mean_brightness_err_ch_1 = self.FCS_results_ch_1.Brightness.std(ddof=1)
        dpg.configure_item('Brightness_input_ch_1', default_value=self.mean_brightness_ch_1)
        dpg.configure_item('Brightness_err_input_ch_1', default_value=self.mean_brightness_err_ch_1)

    def mean_bright_input_ch_2(self):

        self.mean_brightness_ch_2 = self.FCS_results_ch_2.Brightness.mean()
        self.mean_brightness_err_ch_2 = self.FCS_results_ch_2.Brightness.std(ddof=1)
        dpg.configure_item('Brightness_input_ch_2', default_value=self.mean_brightness_ch_2)
        dpg.configure_item('Brightness_err_input_ch_2', default_value=self.mean_brightness_err_ch_2)

    def show_error_no_files(self, error_text):
        try:
            with dpg.window(pos=(400, 150),
                            label='Error!',
                            tag='No_data_files',
                            no_move=True,
                            no_close=False,
                            no_title_bar=False,
                            no_resize=True,
                            show=True,
                            modal=True
                            ):
                dpg.add_text(error_text, tag='no_files_error_text')
                dpg.add_button(label='Close',
                               tag='no_files_error_butt',
                               show=True,
                               callback=self.callback_no_files_dialog_close_only
                               )
                dpg.bind_item_theme('No_data_files', 'Error_window_theme')
        except:
            dpg.show_item('No_data_files')

    def update_dialogs_default_directory(self, last_directory):

        self._GI.last_directory = last_directory
        dpg.configure_item('ROI_folder_dialog_id', default_path=last_directory)
        dpg.configure_item('file_dialog_id', default_path=last_directory)
        dpg.configure_item('PTU_file_dialog_id', default_path=last_directory)
        dpg.configure_item('Select_ROI_dialog', default_path=last_directory)
        dpg.configure_item('file_dialog_export', default_path=last_directory)
        dpg.configure_item('Calib_file_dialog_id', default_path=last_directory)

    def update_flist(self, fs):
        '''Updates the filelist. '''

        if not len(fs) == 0:
            try:
                dpg.configure_item("file_box", items=fs)

                dpg.configure_item("file_box", default_value=fs[0])
            except:
                pass
        else:
            dpg.configure_item("file_box", items=())
            dpg.configure_item("file_box", default_value='')


    def callback_exportsettings(self, sender, app_data):
        setts = {
            'Calib_data': {
                'Calib_file_path': self.calib_directory,
                'Ch_1_omega': dpg.get_value('omega_input_ch_1'),
                'Ch_1_omega_err': dpg.get_value('omega_err_input_ch_1'),
                'Ch_1_kappa': dpg.get_value('kappa_input_ch_1'),
                'Ch_1_kappa_err': dpg.get_value('kappa_err_input_ch_1'),
                'Ch_1_V0': dpg.get_value('focal_vol_input_ch_1'),
                'Ch_1_V0_err': dpg.get_value('focal_vol_err_input_ch_1'),
                'Ch_1_B': dpg.get_value('Brightness_input_ch_1'),
                'Ch_1_B_err': dpg.get_value('Brightness_err_input_ch_1'),
                'Ch_2_omega': dpg.get_value('omega_input_ch_2'),
                'Ch_2_omega_err': dpg.get_value('omega_err_input_ch_2'),
                'Ch_2_kappa': dpg.get_value('kappa_input_ch_2'),
                'Ch_2_kappa_err': dpg.get_value('kappa_err_input_ch_2'),
                'Ch_2_V0': dpg.get_value('focal_vol_input_ch_2'),
                'Ch_2_V0_err': dpg.get_value('focal_vol_err_input_ch_2'),
                'Ch_2_B': dpg.get_value('Brightness_input_ch_2'),
                'Ch_2_B_err': dpg.get_value('Brightness_err_input_ch_2'),

            },
            'PTU_files_dir': self.PTU_directory,
            'ROI_file_dir': self.ROI_directory,
            'Export_opts': {
                'Photons to array': dpg.get_value('Photons_array_checkbox'),
                'Photons to heatmap': dpg.get_value('Photons_Hmaps_checkbox'),
                'N_p to array': dpg.get_value('Np_array_checkbox'),
                'N_p to heatmap': dpg.get_value('Np_Hmaps_checkbox'),
                'Conc. to array': dpg.get_value('C_array_checkbox'),
                'Conc. to heatmap': dpg.get_value('C_Hmaps_checkbox')

            },
            'Error_notation': dpg.get_value('Error_type_checkbox')

        }


        if self.PTU_directory != None:
            path_to_json_file = os.path.join(self.PTU_directory, 'workspace_info.json')
            with open(path_to_json_file, 'w') as f:
                json.dump(setts, f, indent=4, sort_keys=False)
        else:
            pass

    def _pkl_file(self):

        pkl = {
            'filename': self.anal_file,
            'ROI_mode': (dpg.get_value('FILE_ROI_checkbox'), dpg.get_value('Auto_ROI_checkbox')),
            'FCS_data': {
                'omega_1': dpg.get_value('omega_input_ch_1'),
                'omega_2': dpg.get_value('omega_input_ch_2'),
                'omega_err_1': dpg.get_value('omega_err_input_ch_1'),
                'omega_err_2': dpg.get_value('omega_err_input_ch_2'),
                'kappa_1': dpg.get_value('kappa_input_ch_1'),
                'kappa_2': dpg.get_value('kappa_input_ch_2'),
                'kappa_err_1': dpg.get_value('kappa_err_input_ch_1'),
                'kappa_err_2': dpg.get_value('kappa_err_input_ch_2'),
                'fv_1': dpg.get_value('focal_vol_input_ch_1'),
                'fv_2': dpg.get_value('focal_vol_input_ch_2'),
                'fv_err_1': dpg.get_value('focal_vol_err_input_ch_1'),
                'fv_err_2': dpg.get_value('focal_vol_err_input_ch_2'),
                'Br_1': dpg.get_value('Brightness_input_ch_1'),
                'Br_2': dpg.get_value('Brightness_input_ch_2'),
                'Br_err_1': dpg.get_value('Brightness_err_input_ch_1'),
                'Br_err_2': dpg.get_value('Brightness_err_input_ch_2'),
            },
            'autoroi_thres': {
                'cell_1': dpg.get_value('cell_thres_ratio_1'),
                'cell_2': dpg.get_value('cell_thres_ratio_2'),
                'nucl_1': dpg.get_value('nucl_thres_ratio_1'),
                'nucl_2': dpg.get_value('nucl_thres_ratio_2'),
                'ROI_mode_1': dpg.get_value('ROI_mode_1'),
                'ROI_mode_2': dpg.get_value('ROI_mode_2'),
                'cp_roi_1': dpg.get_value('cp_roi_1'),
                'cp_roi_2': dpg.get_value('cp_roi_2')

            }

        }

        pkl_path = os.path.join(self.PTU_directory, self.anal_file + '.rpk')
        with open(pkl_path, 'wb') as f:
            pickle.dump(pkl, f)

    def _load_pkl_file(self, path):
        with open(path, 'rb') as file:
            pkl = pickle.load(file)

        dpg.set_value('omega_input_ch_1', pkl['FCS_data']['omega_1'])
        dpg.set_value('omega_input_ch_2', pkl['FCS_data']['omega_2'])
        dpg.set_value('omega_err_input_ch_1', pkl['FCS_data']['omega_err_1'])
        dpg.set_value('omega_err_input_ch_2', pkl['FCS_data']['omega_err_2'])
        dpg.set_value('kappa_input_ch_1', pkl['FCS_data']['kappa_1'])
        dpg.set_value('kappa_input_ch_2', pkl['FCS_data']['kappa_2'])
        dpg.set_value('kappa_err_input_ch_1', pkl['FCS_data']['kappa_err_1'])
        dpg.set_value('kappa_err_input_ch_2', pkl['FCS_data']['kappa_err_2'])
        Vf1 = self.VEFF(pkl['FCS_data']['omega_1'], pkl['FCS_data']['kappa_1'], pkl['FCS_data']['omega_err_1'], pkl['FCS_data']['kappa_err_1'])
        Vf2 = self.VEFF(pkl['FCS_data']['omega_2'], pkl['FCS_data']['kappa_2'], pkl['FCS_data']['omega_err_2'], pkl['FCS_data']['kappa_err_2'])
        dpg.set_value('focal_vol_input_ch_1', Vf1[0])
        dpg.set_value('focal_vol_input_ch_2', Vf2[0])
        dpg.set_value('focal_vol_err_input_ch_1', Vf1[1])
        dpg.set_value('focal_vol_err_input_ch_2', Vf2[1])
        dpg.set_value('Brightness_input_ch_1', pkl['FCS_data']['Br_1'])
        dpg.set_value('Brightness_input_ch_2', pkl['FCS_data']['Br_2'])
        dpg.set_value('Brightness_err_input_ch_1', pkl['FCS_data']['Br_err_1'])
        dpg.set_value('Brightness_err_input_ch_2', pkl['FCS_data']['Br_err_2'])
        dpg.set_value('cell_thres_ratio_1', pkl['autoroi_thres']['cell_1'])
        dpg.set_value('cell_thres_ratio_2', pkl['autoroi_thres']['cell_2'])
        dpg.set_value('nucl_thres_ratio_1', pkl['autoroi_thres']['nucl_1'])
        dpg.set_value('nucl_thres_ratio_2', pkl['autoroi_thres']['nucl_2'])
        dpg.set_value('ROI_mode_1', pkl['autoroi_thres']['ROI_mode_1'])
        dpg.set_value('ROI_mode_2', pkl['autoroi_thres']['ROI_mode_2'])
        dpg.set_value('cp_roi_1', pkl['autoroi_thres']['cp_roi_1'])
        dpg.set_value('cp_roi_2', pkl['autoroi_thres']['cp_roi_2'])
        dpg.set_value('FILE_ROI_checkbox', pkl['ROI_mode'][0])
        dpg.set_value('Auto_ROI_checkbox', pkl['ROI_mode'][1])
        if pkl['ROI_mode'][1]:
            self.set_roi_state()
            self.callback_select_autoroi('Auto_ROI_checkbox', pkl['ROI_mode'][1])

        else:
            self.set_roi_state()
            self.callback_select_roi('FILE_ROI_checkbox', pkl['ROI_mode'][0])

        return pkl

        
####################################################################
################ end of _Phot2conc_vars_funct class ################
#################################################################### 



    def mount_fcs_handlers(self):
        if not dpg.does_item_exist('keyword_handler_fcs_up'):
            dpg.add_key_press_handler(
                key=self.up_key,
                tag='keyword_handler_fcs_up',
                callback=self.callback_PTUConc_Keyword_key,
                parent='handlers_registry'
            )
        if not dpg.does_item_exist('keyword_handler_fcs_down'):
            dpg.add_key_press_handler(
                key=self.down_key,
                tag='keyword_handler_fcs_down',
                callback=self.callback_PTUConc_Keyword_key,
                parent='handlers_registry'
            )
        # globalITEMS.windows.extend(['keyword_handler_fcs_up','keyword_handler_fcs_up'])
    
    def callback_PTUConc_Keyword_key(self, sender, app_data):
        dlgs = [dpg.is_item_shown(d) for d in self.DialWinList]
    
        if any(dlgs):
            return
    
        if 'file_box' not in dpg.get_aliases():
            return
    
        file_box_items = dpg.get_item_configuration('file_box')['items']
        if not file_box_items:
            return
    
        def_val = dpg.get_value('file_box')
        if def_val not in file_box_items:
            return
    
        index = file_box_items.index(def_val)
    
        if app_data == self.up_key and index > 0:
            index -= 1
            dpg.set_value('file_box', file_box_items[index])
            self.callback_listbox('file_box', file_box_items[index])
    
        elif app_data == self.down_key and index < len(file_box_items) - 1:
            index += 1
            dpg.set_value('file_box', file_box_items[index])
            self.callback_listbox('file_box', file_box_items[index])
