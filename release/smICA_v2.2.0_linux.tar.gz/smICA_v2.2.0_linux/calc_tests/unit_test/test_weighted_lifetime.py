# This file is part of the smICA repository that is distributed under the MIT license; see below.
#
#
# ############################################################################
#
# MIT License
#
# Copyright (c) 2026 Tomasz Kalwarczyk
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


"""Validate weighted lifetime calculation and empty-pixel handling."""

import numpy as np

from test_support import prepare_imports, report_close

prepare_imports()

from Modes.Extract_from_PTU.PhotExtract_INIT import _PhotExtr_vars_funct


# Fractional values must not be truncated before division.
print("Purpose: verify weighted mean lifetimes and invalid-pixel handling.")
print("A valid lifetime equals weighted time sum divided by weighted intensity.")

weighted_time = np.array([[2.5, 9.0], [0.0, 4.5]])
intensity = np.array([[2.0, 3.0], [0.0, np.nan]])
result = _PhotExtr_vars_funct._weighted_lifetime_map(weighted_time, intensity)

expected = np.array([[1.25, 3.0], [np.nan, np.nan]])
report_close("Weighted lifetime image", expected, result, "time bins")

print("PASS: weighted lifetime map")


print("Purpose: keep a library decay separate from an identically named current decay.")
name = "(Ch1) Dextran pattern.ptu"
decays = [name]
_PhotExtr_vars_funct._append_library_decay_name(decays, name)
print(f"  Expected rows:   {[name, name]}")
print(f"  Calculated rows: {decays}")
assert decays == [name, name]

_PhotExtr_vars_funct._append_library_decay_name(decays, name)
print(f"  Rows after repeated import: {decays}")
assert decays == [name, name]

print("PASS: library/current decay name collision")
